package com.example.data.repositories

import android.content.Context
import android.util.Log
import com.example.data.local.ChatLocalDataSource
import com.example.data.models.*
import com.example.utils.AnalyticsEventsHelper
import com.example.utils.AppError
import com.example.utils.AppResult
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await

/**
 * 🚀 ChatRepository
 * تطبيق مستودع المحادثات الشامل بنظام (Offline-First) والمزامنة الحية (Realtime Delta Sync)
 * - قراءة فورية من التخزين المحلي المشفر
 * - مزامنة تفاضلية ذكية مع Firebase Firestore
 * - حل تعارضات تلقائي (Conflict Resolution)
 * - إدارة دورة حياة المستمعات بدون تسريب للذاكرة
 * - معالجة أخطاء موحدة عبر AppResult و AppError
 */
class ChatRepository(
    private val context: Context? = null,
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val localDataSource: ChatLocalDataSource? = null
) : IChatRepository {

    private val local: ChatLocalDataSource? by lazy {
        localDataSource ?: context?.let { ChatLocalDataSource.getInstance(it) }
    }

    private val channelsCollection = firestore.collection("chat_channels")
    private val presenceCollection = firestore.collection("user_presence")

    companion object {
        const val SUPPORT_ADMIN_ID = "ADMIN"
        const val SUPPORT_ADMIN_NAME = "الدعم الفني"
    }

    // =========================================================================
    // 1. CHANNELS MANAGEMENT (OFFLINE-FIRST)
    // =========================================================================


    override suspend fun getOrCreateChannel(
        currentUserId: String,
        currentUserName: String,
        currentUserPhoto: String,
        otherUserId: String,
        otherUserName: String,
        otherUserPhoto: String,
        type: ChannelType,
        relatedEntityId: String?,
        relatedEntityType: String?
    ): AppResult<ChatChannel> = withContext(Dispatchers.IO) {
        try {
            val cleanCurrent = currentUserId.trim()
            val cleanOther = if (type == ChannelType.SUPPORT) SUPPORT_ADMIN_ID else otherUserId.trim()
            val finalOtherName = if (type == ChannelType.SUPPORT) SUPPORT_ADMIN_NAME else otherUserName
            
            if (cleanCurrent.isBlank()) {
                return@withContext AppResult.Error(AppError.ValidationError("currentUserId", "معرف المستخدم الحالي فارغ"))
            }

            val sortedParticipants = listOf(cleanCurrent, cleanOther).filter { it.isNotBlank() }.sorted()
            
            var customChannelId: String? = null

            if (type == ChannelType.SUPPORT) {
                try {
                    val existingSupportQuery = channelsCollection
                        .whereArrayContains("participants", cleanCurrent)
                        .get().await()
                    
                    val existingSupportDoc = existingSupportQuery.documents.find { doc ->
                        val docType = doc.getString("type") ?: ""
                        val docTitle = doc.getString("title") ?: ""
                        val docId = doc.id
                        docType.equals("SUPPORT", ignoreCase = true) || 
                            docTitle == SUPPORT_ADMIN_NAME || 
                            docId.startsWith("support_") ||
                            docId == "channel_support_${cleanCurrent}"
                    }
                    
                    if (existingSupportDoc != null) {
                        customChannelId = existingSupportDoc.id
                    }
                } catch (e: Exception) {
                    Log.w("ChatRepository", "Error searching existing support channel: ${e.message}")
                }
            }

            val finalChannelId = customChannelId ?: when {
                type == ChannelType.SUPPORT -> "channel_support_${cleanCurrent}"
                type == ChannelType.PRIVATE && sortedParticipants.size == 2 -> "channel_${sortedParticipants[0]}_${sortedParticipants[1]}"
                relatedEntityId != null -> "channel_${type.name.lowercase()}_${relatedEntityId.trim()}"
                else -> channelsCollection.document().id
            }

            val docRef = channelsCollection.document(finalChannelId)
            
            // 🚀 Check local cache first before Firestore request
            val localChannel = local?.getChannelById(finalChannelId)
            if (localChannel != null && localChannel.participants.contains(cleanCurrent)) {
                return@withContext AppResult.Success(localChannel)
            }

            val snapshot = docRef.get().await()

            val channelToReturn = if (snapshot.exists()) {
                val existing = snapshot.toObject(ChatChannel::class.java)?.copy(id = snapshot.id) ?: ChatChannel(id = finalChannelId)
                val updatedNames = existing.participantNames.toMutableMap().apply {
                    put(cleanCurrent, currentUserName)
                    if (cleanOther.isNotBlank() && finalOtherName.isNotBlank()) put(cleanOther, finalOtherName)
                }
                val updatedPhotos = existing.participantPhotos.toMutableMap().apply {
                    put(cleanCurrent, currentUserPhoto)
                    if (cleanOther.isNotBlank() && otherUserPhoto.isNotBlank()) put(cleanOther, otherUserPhoto)
                }
                
                val finalChannel = existing.copy(
                    participantNames = updatedNames, 
                    participantPhotos = updatedPhotos,
                    type = if (type == ChannelType.SUPPORT) ChannelType.SUPPORT else existing.type,
                    title = if (type == ChannelType.SUPPORT) "الدعم الفني" else existing.title
                )
                
                if (updatedNames != existing.participantNames || updatedPhotos != existing.participantPhotos) {
                    docRef.update(
                        mapOf(
                            "participantNames" to updatedNames,
                            "participantPhotos" to updatedPhotos,
                            "type" to finalChannel.type.name,
                            "title" to finalChannel.title
                        )
                    ).await()
                }
                local?.saveOrUpdateChannel(finalChannel)
                finalChannel
            } else {
                val newChannel = ChatChannel(
                    id = finalChannelId,
                    participants = listOf(cleanCurrent, cleanOther).filter { it.isNotBlank() },
                    participantNames = mutableMapOf(cleanCurrent to currentUserName).apply {
                        if (cleanOther.isNotBlank() && finalOtherName.isNotBlank()) put(cleanOther, finalOtherName)
                    },
                    participantPhotos = mutableMapOf(cleanCurrent to currentUserPhoto).apply {
                        if (cleanOther.isNotBlank() && otherUserPhoto.isNotBlank()) put(cleanOther, otherUserPhoto)
                    },
                    type = type,
                    title = if (type == ChannelType.SUPPORT) "الدعم الفني" else "",
                    relatedEntityId = relatedEntityId,
                    relatedEntityType = relatedEntityType,
                    lastMessageTime = System.currentTimeMillis()
                )
                docRef.set(newChannel).await()
                local?.saveOrUpdateChannel(newChannel)
                newChannel
            }
            AnalyticsEventsHelper.logChatOpened(context, channelToReturn.id, otherUserId)
            AppResult.Success(channelToReturn)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }
    override suspend fun getChannelById(channelId: String): AppResult<ChatChannel?> = withContext(Dispatchers.IO) {
        if (channelId.isBlank()) return@withContext AppResult.Success(null)
        try {
            // Local first
            val cached = local?.getChannelById(channelId)
            if (cached != null) {
                return@withContext AppResult.Success(cached)
            }

            // Remote fallback
            val snapshot = channelsCollection.document(channelId).get().await()
            if (snapshot.exists()) {
                val channel = snapshot.toObject(ChatChannel::class.java)?.copy(id = snapshot.id)
                if (channel != null) {
                    local?.saveOrUpdateChannel(channel)
                }
                AppResult.Success(channel)
            } else {
                AppResult.Success(null)
            }
        } catch (e: Exception) {
            val cached = local?.getChannelById(channelId)
            if (cached != null) AppResult.Success(cached)
            else AppResult.Error(AppError.NetworkError(e))
        }
    }

    override fun getUserChannels(userId: String): Flow<List<ChatChannel>> = callbackFlow {
        val cleanUserId = userId.trim()
        if (cleanUserId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        // 1. Emit local cache immediately for instant UI
        local?.getChannels()?.let { cached ->
            if (cached.isNotEmpty()) {
                trySend(cached)
            }
        }

        // 2. Attach Firestore Realtime Listener (Limited to 50 active channels to conserve Firestore quota)
        val listener: ListenerRegistration = channelsCollection
            .whereArrayContains("participants", cleanUserId)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("ChatRepository", "Firestore channels listener error: ${error.message}")
                    return@addSnapshotListener
                }

                val allRemoteChannels = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(ChatChannel::class.java)?.copy(id = doc.id)
                }?.sortedByDescending { it.lastMessageTime } ?: emptyList()

                // For ADMIN: see all support channels from all users
                // For Regular User: Deduplicate SUPPORT channels: keep only their own newest one
                val remoteChannels = if (cleanUserId.equals("ADMIN", ignoreCase = true)) {
                    allRemoteChannels
                } else {
                    val supportChannels = allRemoteChannels.filter { 
                        it.type == ChannelType.SUPPORT || it.title == "الدعم الفني" || it.id.startsWith("support_") 
                    }
                    val otherChannels = allRemoteChannels.filter { 
                        it.type != ChannelType.SUPPORT && it.title != "الدعم الفني" && !it.id.startsWith("support_") 
                    }
                    val latestSupport = supportChannels.maxByOrNull { it.lastMessageTime }
                    (otherChannels + listOfNotNull(latestSupport)).sortedByDescending { it.lastMessageTime }
                }

                // Save to local cache & emit
                CoroutineScope(Dispatchers.IO).launch {
                    local?.saveChannels(remoteChannels)
                }
                trySend(remoteChannels)
            }

        awaitClose {
            try {
                listener.remove()
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }.flowOn(Dispatchers.IO)

    // =========================================================================
    // 2. MESSAGES MANAGEMENT (OFFLINE-FIRST & DELTA SYNC)
    // =========================================================================

    override fun getChannelMessages(channelId: String, currentUserId: String, limit: Int): Flow<List<ChatMessage>> = callbackFlow {
        if (channelId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        // 1. Emit local cache immediately
        val cached = local?.getMessages(channelId) ?: emptyList()
        val visibleCached = cached.filter { !it.isHiddenFor(currentUserId) }
        trySend(visibleCached)

        // 2. Real-time Firebase Listener with limit to reduce read quota
        val messagesRef = channelsCollection.document(channelId).collection("messages")
        val listener = messagesRef
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .limitToLast(limit.coerceAtLeast(10).toLong())
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("ChatRepository", "Messages listener error: ${error.message}")
                    return@addSnapshotListener
                }

                val remoteMessages = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(ChatMessage::class.java)?.copy(id = doc.id)
                } ?: emptyList()

                CoroutineScope(Dispatchers.IO).launch {
                    // Conflict Resolution: merge local pending messages with remote messages
                    val currentLocal = local?.getMessages(channelId) ?: emptyList()
                    val pendingLocal = currentLocal.filter { it.status == MessageStatus.PENDING || it.status == MessageStatus.SENDING }

                    val mergedMap = LinkedHashMap<String, ChatMessage>()
                    // Add remote confirmed
                    for (remote in remoteMessages) {
                        mergedMap[remote.id] = remote
                    }
                    // Retain pending that haven't landed in remote yet
                    for (pending in pendingLocal) {
                        if (!mergedMap.containsKey(pending.id)) {
                            mergedMap[pending.id] = pending
                        }
                    }

                    val mergedList = mergedMap.values.sortedBy { it.timestamp }
                    local?.saveMessages(channelId, mergedList)
                    local?.setLastSyncTimestamp(channelId, System.currentTimeMillis())

                    val visible = mergedList.filter { !it.isHiddenFor(currentUserId) }
                    trySend(visible)
                }
            }

        awaitClose {
            try {
                listener.remove()
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendMessage(
        channelId: String,
        senderId: String,
        senderName: String,
        messageText: String,
        mediaType: MediaType,
        mediaUrl: String,
        replyToId: String?,
        replyToText: String?,
        attachment: ChatAttachment?
    ): AppResult<ChatMessage> = withContext(Dispatchers.IO) {
        try {
            if (channelId.isBlank() || senderId.isBlank()) {
                return@withContext AppResult.Error(AppError.ValidationError("message", "بيانات الرسالة غير مكتملة"))
            }

            val messageId = channelsCollection.document(channelId).collection("messages").document().id
            val now = System.currentTimeMillis()

            val initialMsg = ChatMessage(
                id = messageId,
                channelId = channelId,
                senderId = senderId,
                senderName = senderName,
                message = messageText,
                mediaType = mediaType,
                mediaUrl = mediaUrl,
                attachment = attachment,
                replyToId = replyToId,
                replyToText = replyToText,
                status = MessageStatus.SENDING,
                timestamp = now,
                syncStatus = SyncStatus.PENDING_UPLOAD
            )

            // 1. Immediately store in local cache with SENDING state for instant UI
            local?.insertOrUpdateMessage(initialMsg)

            // 2. Attempt remote send
            val channelRef = channelsCollection.document(channelId)
            val channelSnapshot = channelRef.get().await()
            val channel = channelSnapshot.toObject(ChatChannel::class.java)

            if (channel != null && channel.isUserBlocked(senderId)) {
                local?.updateMessageStatus(channelId, messageId, MessageStatus.FAILED)
                return@withContext AppResult.Error(AppError.UnauthorizedError("لا يمكنك إرسال الرسالة لأنك محظور في هذه المحادثة."))
            }

            val confirmedMsg = initialMsg.copy(status = MessageStatus.SENT, syncStatus = SyncStatus.SYNCED)
            channelRef.collection("messages").document(messageId).set(confirmedMsg).await()

            // Update Channel metadata & increment unread counts
            val updatedUnread = (channel?.unreadCount ?: emptyMap()).toMutableMap()
            channel?.participants?.forEach { pId ->
                if (pId != senderId) {
                    val count = updatedUnread[pId] ?: 0
                    updatedUnread[pId] = count + 1
                }
            }

            val displayLast = when (mediaType) {
                MediaType.IMAGE -> "📷 صورة"
                MediaType.VIDEO -> "🎥 فيديو"
                MediaType.AUDIO -> "🎤 تسجيل صوتي"
                MediaType.FILE -> "📎 ${attachment?.fileName.orEmpty().ifBlank { "ملف مرفق" }}"
                MediaType.LOCATION -> "📍 موقع جغرافي"
                MediaType.CALL -> "📞 مكالمة صوتية"
                MediaType.TEXT -> messageText
            }

            channelRef.update(
                mapOf(
                    "lastMessage" to displayLast,
                    "lastMessageTime" to now,
                    "lastMessageSenderId" to senderId,
                    "unreadCount" to updatedUnread,
                    "updatedAt" to now
                )
            ).await()

            // Update local to SENT
            local?.insertOrUpdateMessage(confirmedMsg)
            AppResult.Success(confirmedMsg)
        } catch (e: Exception) {
            Log.e("ChatRepository", "sendMessage failed, saving to offline queue: ${e.message}")
            // Fallback: Queue message offline
            val offlineMsg = ChatMessage(
                id = java.util.UUID.randomUUID().toString(),
                channelId = channelId,
                senderId = senderId,
                senderName = senderName,
                message = messageText,
                mediaType = mediaType,
                mediaUrl = mediaUrl,
                attachment = attachment,
                replyToId = replyToId,
                replyToText = replyToText,
                status = MessageStatus.PENDING,
                timestamp = System.currentTimeMillis(),
                syncStatus = SyncStatus.PENDING_UPLOAD
            )
            local?.queuePendingMessage(offlineMsg)
            AppResult.Success(offlineMsg)
        }
    }

    override suspend fun retryPendingMessages(currentUserId: String): AppResult<Int> = withContext(Dispatchers.IO) {
        try {
            val pending = local?.getPendingMessages() ?: emptyList()
            var successCount = 0

            for (msg in pending) {
                val sendResult = sendMessage(
                    channelId = msg.channelId,
                    senderId = msg.senderId,
                    senderName = msg.senderName,
                    messageText = msg.message,
                    mediaType = msg.mediaType,
                    mediaUrl = msg.mediaUrl,
                    replyToId = msg.replyToId,
                    replyToText = msg.replyToText,
                    attachment = msg.attachment
                )
                if (sendResult is AppResult.Success) {
                    local?.removePendingMessage(msg.id)
                    successCount++
                }
            }
            AppResult.Success(successCount)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun markChannelAsRead(channelId: String, currentUserId: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || currentUserId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            // Local update first
            local?.markMessagesAsRead(channelId, currentUserId)

            // Remote update
            val channelRef = channelsCollection.document(channelId)
            try {
                channelRef.update("unreadCount.$currentUserId", 0).await()
            } catch (e: Exception) {
                // If field doesn't exist yet, ignore
            }

            // Update status of incoming messages to READ
            val unreadSnapshot = channelRef.collection("messages").get().await()
            val unreadDocs = unreadSnapshot.documents.filter { doc ->
                val senderId = doc.getString("senderId") ?: ""
                val status = doc.getString("status") ?: ""
                senderId != currentUserId && status != MessageStatus.READ.name
            }

            if (unreadDocs.isNotEmpty()) {
                val batch = firestore.batch()
                for (doc in unreadDocs) {
                    batch.update(
                        doc.reference,
                        mapOf(
                            "status" to MessageStatus.READ.name,
                            "isRead" to true,
                            "readAt" to System.currentTimeMillis()
                        )
                    )
                }
                batch.commit().await()
            }
            AppResult.Success(Unit)
        } catch (e: Exception) {
            Log.e("ChatRepository", "markChannelAsRead error: ${e.message}")
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun setTyping(channelId: String, userId: String, isTyping: Boolean): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || userId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            channelsCollection.document(channelId).update("isTyping.$userId", isTyping).await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun toggleBlockUser(channelId: String, userIdToBlock: String, isBlocked: Boolean): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || userIdToBlock.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            channelsCollection.document(channelId).update("blockedUsers.$userIdToBlock", isBlocked).await()
            val cached = local?.getChannelById(channelId)
            if (cached != null) {
                val updatedBlocked = cached.blockedUsers.toMutableMap().apply { put(userIdToBlock, isBlocked) }
                local?.saveOrUpdateChannel(cached.copy(blockedUsers = updatedBlocked))
            }
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun editMessage(
        channelId: String,
        messageId: String,
        newText: String
    ): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || messageId.isBlank() || newText.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            val msgRef = channelsCollection.document(channelId).collection("messages").document(messageId)
            msgRef.update(
                mapOf(
                    "message" to newText.trim(),
                    "isEdited" to true,
                    "editTimestamp" to System.currentTimeMillis()
                )
            ).await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun deleteMessage(
        channelId: String,
        messageId: String,
        forEveryone: Boolean,
        currentUserId: String
    ): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || messageId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            // Local update
            if (forEveryone) {
                local?.deleteMessage(channelId, messageId)
            }

            // Remote update
            val msgRef = channelsCollection.document(channelId).collection("messages").document(messageId)
            if (forEveryone) {
                msgRef.update(
                    mapOf(
                        "isDeleted" to true,
                        "message" to "تم حذف هذه الرسالة"
                    )
                ).await()
            } else {
                msgRef.update("deletedForUsers", FieldValue.arrayUnion(currentUserId)).await()
            }
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun toggleReaction(
        channelId: String,
        messageId: String,
        userId: String,
        emoji: String
    ): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank() || messageId.isBlank() || userId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            val msgRef = channelsCollection.document(channelId).collection("messages").document(messageId)
            val snapshot = msgRef.get().await()
            val currentReactions = snapshot.toObject(ChatMessage::class.java)?.reactions?.toMutableMap() ?: mutableMapOf()

            if (currentReactions[userId] == emoji) {
                currentReactions.remove(userId)
            } else {
                currentReactions[userId] = emoji
            }

            msgRef.update("reactions", currentReactions).await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override suspend fun deleteChannel(channelId: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            local?.deleteChannel(channelId)
            val channelDocRef = channelsCollection.document(channelId)
            val msgsSnapshot = channelDocRef.collection("messages").get().await()
            val batch = firestore.batch()
            for (doc in msgsSnapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.delete(channelDocRef)
            batch.commit().await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            Log.e("ChatRepository", "deleteChannel error: ${e.message}")
            AppResult.Success(Unit)
        }
    }

    override suspend fun deleteAllChannels(channelsList: List<ChatChannel>): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (channelsList.isEmpty()) return@withContext AppResult.Success(Unit)
        try {
            local?.clearAllChannels()
            val batch = firestore.batch()
            channelsList.forEach { ch ->
                batch.delete(channelsCollection.document(ch.id))
            }
            batch.commit().await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    // =========================================================================
    // 3. USER PRESENCE
    // =========================================================================

    override suspend fun setUserPresence(userId: String, isOnline: Boolean): AppResult<Unit> = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext AppResult.Success(Unit)
        try {
            val presence = UserPresence(
                userId = userId,
                isOnline = isOnline,
                lastSeen = System.currentTimeMillis()
            )
            local?.saveUserPresence(presence)
            presenceCollection.document(userId).set(presence, SetOptions.merge()).await()
            AppResult.Success(Unit)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }

    override fun getUserPresence(userId: String): Flow<UserPresence?> = callbackFlow {
        if (userId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        // Local cache emission first
        local?.observeUserPresence(userId)?.let { localFlow ->
            CoroutineScope(Dispatchers.IO).launch {
                localFlow.collect { cached ->
                    trySend(cached)
                }
            }
        }

        val listener = presenceCollection.document(userId).addSnapshotListener { snapshot, _ ->
            val presence = snapshot?.toObject(UserPresence::class.java)
            if (presence != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    local?.saveUserPresence(presence)
                }
            }
            trySend(presence)
        }

        awaitClose {
            try {
                listener.remove()
            } catch (e: Exception) {
                // تجاهل
            }
        }
    }.flowOn(Dispatchers.IO)

    override fun getTypingStatus(channelId: String, userId: String): Flow<Boolean> = callbackFlow {
        if (channelId.isBlank() || userId.isBlank()) {
            trySend(false)
            close()
            return@callbackFlow
        }

        val listener = channelsCollection.document(channelId).addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(false)
                return@addSnapshotListener
            }
            val isTypingMap = snapshot?.get("isTyping") as? Map<*, *>
            val isTyping = (isTypingMap?.get(userId) as? Boolean) ?: false
            trySend(isTyping)
        }

        awaitClose {
            try {
                listener.remove()
            } catch (_: Exception) {}
        }
    }.flowOn(Dispatchers.IO)

    // =========================================================================
    // 4. DELTA SYNC IMPLEMENTATION
    // =========================================================================

    override suspend fun syncChannelDelta(channelId: String): AppResult<Int> = withContext(Dispatchers.IO) {
        if (channelId.isBlank()) return@withContext AppResult.Success(0)
        try {
            val lastSync = local?.getLastSyncTimestamp(channelId) ?: 0L
            val messagesRef = channelsCollection.document(channelId).collection("messages")

            val snapshot = if (lastSync > 0) {
                messagesRef.whereGreaterThan("timestamp", lastSync).get().await()
            } else {
                messagesRef.orderBy("timestamp", Query.Direction.DESCENDING).limit(50).get().await()
            }

            val newMessages = snapshot.documents.mapNotNull { doc ->
                doc.toObject(ChatMessage::class.java)?.copy(id = doc.id)
            }

            if (newMessages.isNotEmpty()) {
                val current = local?.getMessages(channelId) ?: emptyList()
                val merged = (current + newMessages).distinctBy { it.id }.sortedBy { it.timestamp }
                local?.saveMessages(channelId, merged)
                local?.setLastSyncTimestamp(channelId, System.currentTimeMillis())
            }

            AppResult.Success(newMessages.size)
        } catch (e: Exception) {
            AppResult.Error(AppError.NetworkError(e))
        }
    }
}
