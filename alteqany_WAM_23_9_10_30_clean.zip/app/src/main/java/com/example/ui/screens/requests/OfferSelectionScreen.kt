package com.example.ui.screens.requests

import android.content.Intent
import com.example.ui.*
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.BookingEntity
import com.example.data.NotificationEntity
import com.example.data.models.ChannelType
import com.example.data.models.ChatChannel
import com.example.data.models.InstantRequestEntity
import com.example.data.models.RequestOfferEntity
import com.example.ui.MainViewModel
import com.example.ui.viewmodels.InstantRequestViewModel
import com.example.utils.DateFormatter
import kotlinx.coroutines.launch
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

/**
 * ✅ OfferSelectionScreen
 * شاشة اختيار العرض المناسب وتثبيت موعد الحجز وتوليد كود الحجز الآمن
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfferSelectionScreen(
    offerId: String,
    viewModel: MainViewModel,
    instantViewModel: InstantRequestViewModel = androidx.hilt.navigation.compose.hiltViewModel(),
    onNavigateBack: () -> Unit = {},
    onBookingConfirmed: (bookingId: String) -> Unit = {},
    onNavigateToChat: (phone: String, name: String) -> Unit = { _, _ -> },
    onNavigateToDirectChannel: (channel: ChatChannel) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUserId by viewModel.currentUserId.collectAsState()
    val currentUserName by viewModel.currentUserName.collectAsState()
    val currentUserPhone by viewModel.currentUserPhone.collectAsState()

    var offer by remember { mutableStateOf<RequestOfferEntity?>(null) }
    var request by remember { mutableStateOf<InstantRequestEntity?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    // ✨ م2-ج3: استخدام DateFormatter
    var selectedDate by remember {
        mutableStateOf(DateFormatter.formatDateDash(System.currentTimeMillis()))
    }
    var selectedTime by remember {
        mutableStateOf(DateFormatter.formatTime24(System.currentTimeMillis() + 3600 * 1000L))
    }
    var userNotes by remember { mutableStateOf("") }
    var userPin by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    var showConfirmationSuccessDialog by remember { mutableStateOf(false) }
    var createdBookingNumber by remember { mutableStateOf("") }
    var newlyCreatedChannel by remember { mutableStateOf<ChatChannel?>(null) }

    LaunchedEffect(offerId) {
        if (offerId.isNotBlank()) {
            isLoading = true
            instantViewModel.loadOfferAndRequest(offerId) { o, r ->
                offer = o
                request = r
                isLoading = false
            }
        } else {
            isLoading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تأكيد واختيار العرض", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            )
        }
    ) { paddingValues ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val curOffer = offer
        val curReq = request

        if (curOffer == null || curReq == null) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("العرض أو الطلب غير موجود.", color = MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        if (offerId.isNotBlank()) {
                            isLoading = true
                            instantViewModel.loadOfferAndRequest(offerId) { o, r ->
                                offer = o
                                request = r
                                isLoading = false
                            }
                        }
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إعادة المحاولة")
                    }
                }
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // بطاقة ملخص العرض المختار
            Card(
                modifier = Modifier.fillMaxWidth().testTag("selected_offer_summary_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("بيانات مقدم الخدمة المختار", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(curOffer.technicianName.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text(curOffer.technicianName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFA000), modifier = Modifier.size(16.dp))
                                    Text(" ${curOffer.technicianRating}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Text("${curOffer.price} ر.ي", fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color(0xFF2E7D32))
                    }

                    HorizontalDivider()

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("وقت الوصول: ${curOffer.estimatedArrivalTime}", fontSize = 13.sp)
                        Text("مدة الإنجاز: ${curOffer.estimatedDuration}", fontSize = 13.sp)
                    }

                    if (curOffer.notes.isNotBlank()) {
                        Text("ملاحظات الفني: ${curOffer.notes}", fontSize = 12.sp, color = Color.DarkGray)
                    }
                }
            }

            // بطاقة ملخص الطلب
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الطلب: ${curReq.serviceTitle}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("كود الطلب: ${curReq.requestCode}", fontSize = 12.sp, color = Color.Gray)
                    Text("الموقع: ${curReq.userCity} - ${curReq.userNeighborhood}", fontSize = 12.sp)
                }
            }

            // تحديد وقت وتاريخ الخدمة
            Text("تأكيد الموعد والعنوان", fontWeight = FontWeight.Bold, fontSize = 16.sp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = selectedDate,
                    onValueChange = { selectedDate = it },
                    label = { Text("تاريخ الخدمة") },
                    leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                    modifier = Modifier.weight(1f).testTag("booking_date_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = selectedTime,
                    onValueChange = { selectedTime = it },
                    label = { Text("وقت الحضور") },
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) },
                    modifier = Modifier.weight(1f).testTag("booking_time_input"),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = userNotes,
                onValueChange = { userNotes = it },
                label = { Text("ملاحظات إضافية للفني عند الوصول") },
                modifier = Modifier.fillMaxWidth().height(85.dp).testTag("booking_notes_input"),
                maxLines = 2
            )

            // رمز PIN للأمان
            Text("رمز سري PIN لتأكيد وإدارة الحجز (4 أرقام)*", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = userPin,
                onValueChange = { if (it.length <= 4 && it.all { char -> char.isDigit() }) userPin = it },
                label = { Text("رمز PIN (مثال: 1234)") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth().testTag("booking_pin_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // زر تأكيد الحجز
            Button(
                onClick = {
                    if (userPin.length < 4) {
                        Toast.makeText(context, "يرجى كتابة رمز PIN مكون من 4 أرقام", Toast.LENGTH_SHORT).show()
                        return@Button
                    }

                    if (curReq.status == "COMPLETED" || curReq.status == "CANCELLED") {
                        Toast.makeText(context, "هذا الطلب لم يعد متاحاً للتأكيد (ملغي أو تم اختيار عرض آخر بالفعل).", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (curOffer.status == "REJECTED" || curOffer.status == "CANCELLED") {
                        Toast.makeText(context, "هذا العرض لم يعد صالحاً للاختيار.", Toast.LENGTH_LONG).show()
                        return@Button
                    }

                    isSubmitting = true
                    val bookingId = UUID.randomUUID().toString()
                    // ✨ م2-ج3: استخدام DateFormatter
                    val bNum = "BK-${DateFormatter.formatCustom(System.currentTimeMillis(), "yyMMddHHmm")}-${Random.nextInt(1000, 9999)}"

                    val newBooking = BookingEntity(
                        id = bookingId,
                        bookingNumber = bNum,
                        bookingPassword = "",
                        clientId = curReq.userId,
                        clientName = curReq.userName,
                        clientPhone = curReq.userPhone,
                        clientAddress = "${curReq.userCity} - ${curReq.userNeighborhood}",
                        customerName = curReq.userName,
                        customerPhone = curReq.userPhone,
                        customerArea = "${curReq.userCity} - ${curReq.userNeighborhood}",
                        serviceType = curReq.serviceTitle,
                        providerId = curOffer.technicianId,
                        providerName = curOffer.technicianName,
                        providerPhone = curOffer.technicianPhone,
                        dateString = selectedDate,
                        timeString = selectedTime,
                        date = selectedDate,
                        time = selectedTime,
                        category = curReq.categoryId,
                        subCategory = curReq.categoryName,
                        serviceDetails = "${curReq.description}\nملاحظات: $userNotes",
                        totalAmount = curOffer.price,
                        status = "APPROVED",
                        pinCode = com.example.utils.SecureHasher.hashPin(userPin),
                        createdAt = System.currentTimeMillis()
                    )

                    instantViewModel.confirmOfferSelection(
                        booking = newBooking,
                        curOffer = curOffer,
                        curReq = curReq,
                        onSuccess = {
                            // إنشاء قناة المحادثة فوراً وربطها بالطلب العاجل
                            scope.launch {
                                try {
                                    val effectiveUserId = currentUserId.ifBlank { currentUserPhone.ifBlank { "client_${System.currentTimeMillis()}" } }
                                    val effectiveUserName = currentUserName.ifBlank { "العميل" }
                                    val targetTechId = curOffer.technicianId.ifBlank { curOffer.technicianPhone }
                                    val channelResult = instantViewModel.getOrCreateChatChannel(
                                        currentUserId = effectiveUserId,
                                        currentUserName = effectiveUserName,
                                        currentUserPhoto = "",
                                        otherUserId = targetTechId,
                                        otherUserName = curOffer.technicianName,
                                        otherUserPhoto = curOffer.technicianAvatar,
                                        type = ChannelType.PRIVATE,
                                        relatedEntityId = curReq.id,
                                        relatedEntityType = "URGENT_REQUEST"
                                    )
                                    val createdChannel = channelResult.getOrNull()
                                    if (createdChannel != null) {
                                        newlyCreatedChannel = createdChannel
                                        viewModel.openChatChannel(
                                            com.example.data.ChatChannelEntity(
                                                id = createdChannel.id,
                                                targetId = targetTechId,
                                                targetName = curOffer.technicianName,
                                                targetPhone = curOffer.technicianPhone,
                                                providerId = targetTechId,
                                                providerName = curOffer.technicianName
                                            )
                                        )
                                    }
                                } catch (e: Exception) {
                                    android.util.Log.e("OfferSelection", "Error creating chat channel: ${e.message}")
                                }
                            }
                            isSubmitting = false
                            createdBookingNumber = bNum
                            showConfirmationSuccessDialog = true
                        },
                        onError = { err ->
                            isSubmitting = false
                            Toast.makeText(context, "فشل تأكيد الحجز: $err", Toast.LENGTH_SHORT).show()
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("confirm_booking_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                enabled = !isSubmitting
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تأكيد الحجز والتعاقد مع الفني", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            OutlinedButton(
                onClick = { onNavigateToChat(curOffer.technicianPhone, curOffer.technicianName) },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("محادثة الفني قبل التأكيد")
            }
        }
    }

    if (showConfirmationSuccessDialog) {
        AlertDialog(
            onDismissRequest = {},
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                    Text("تم تأكيد الحجز بنجاح!", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تم إرسال إشعار فوري للفني وتأكيد الموعد رسمياً.")
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("رقم الحجز المرجعي", fontSize = 12.sp, color = Color(0xFF2E7D32))
                            Text(createdBookingNumber, fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFF1B5E20))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("احتفظ برمز PIN لإلغاء أو تعديل الحجز.", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            showConfirmationSuccessDialog = false
                            onBookingConfirmed(createdBookingNumber)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("الحجوزات")
                    }

                    Button(
                        onClick = {
                            showConfirmationSuccessDialog = false
                            newlyCreatedChannel?.let { onNavigateToDirectChannel(it) } ?: run {
                                val tPhone = offer?.technicianPhone ?: ""
                                val tName = offer?.technicianName ?: ""
                                onNavigateToChat(tPhone, tName)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("محادثة الفني الآن")
                    }
                }
            }
        )
    }
}
