plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.secrets) apply false
    alias(libs.plugins.google.devtools.ksp) apply false
    alias(libs.plugins.hilt.android) apply false
    alias(libs.plugins.firebase.crashlytics) apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
    alias(libs.plugins.roborazzi) apply false
}
