package com.example.ui.screens.dashboard.viewmodels

import androidx.lifecycle.ViewModel
import com.example.ui.*
import androidx.lifecycle.viewModelScope
import com.example.data.repositories.IDashboardRepository
import com.example.data.repositories.IProductsRepository
import com.example.data.repositories.IRatingsRepository
import com.example.domain.entities.ProductItemEntity
import com.example.domain.entities.DoctorItem
import com.example.ui.screens.dashboard.DashboardEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.flow.catch
import javax.inject.Inject

@HiltViewModel
class MedicalDashboardViewModel @Inject constructor(
    private val dashboardRepository: IDashboardRepository,
    private val productsRepository: IProductsRepository,
    private val ratingsRepository: IRatingsRepository,
    private val medicalRepository: com.example.data.repositories.MedicalRepository
) : ViewModel() {

    private var ownerId: String = ""

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val _doctors = MutableStateFlow<List<DoctorItem>>(emptySet<DoctorItem>().toList())
    val doctors: StateFlow<List<DoctorItem>> = _doctors.asStateFlow()

    private val _eventFlow = MutableSharedFlow<DashboardEvent>()
    val eventFlow: SharedFlow<DashboardEvent> = _eventFlow.asSharedFlow()

    private var doctorsJob: kotlinx.coroutines.Job? = null
    private var loadJob: kotlinx.coroutines.Job? = null

    fun initialize(id: String) {
        val cleanId = id.trim()
        if (cleanId.isBlank() || ownerId == cleanId) return
        ownerId = cleanId
        loadDashboardData()
        doctorsJob?.cancel()
        doctorsJob = viewModelScope.launch {
            medicalRepository.getDoctors(ownerId)
                .catch { /* silent */ }
                .collect {
                    _doctors.value = it
                }
        }
    }

    fun selectTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(activeTab = tabIndex)
    }

    fun loadDashboardData() {
        if (ownerId.isBlank()) return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            supervisorScope {
                launch {
                    dashboardRepository.getDashboardStats(ownerId, "MEDICAL")
                        .catch { e -> 
                            _eventFlow.emit(DashboardEvent.ShowToast(e.message ?: "خطأ في الإحصائيات")) 
                            _uiState.value = _uiState.value.copy(isLoading = false)
                        }
                        .collect { stats ->
                            _uiState.value = _uiState.value.copy(stats = stats, isLoading = false)
                        }
                }
                launch {
                    productsRepository.getOwnerProducts(ownerId)
                        .catch { e -> _eventFlow.emit(DashboardEvent.ShowToast(e.message ?: "خطأ في المنتجات")) }
                        .collect { prods ->
                            _uiState.value = _uiState.value.copy(products = prods)
                        }
                }
                launch {
                    ratingsRepository.getTargetRatings(ownerId)
                        .catch { e -> _eventFlow.emit(DashboardEvent.ShowToast(e.message ?: "خطأ في التقييمات")) }
                        .collect { revs ->
                            _uiState.value = _uiState.value.copy(reviews = revs)
                        }
                }
            }
        }
    }

    fun addDoctor(name: String, specialty: String, workingHours: String) {
        if (name.isBlank()) {
            viewModelScope.launch {
                _eventFlow.emit(DashboardEvent.ShowToast("يرجى إدخال اسم الطبيب"))
            }
            return
        }
        
        val docId = java.util.UUID.randomUUID().toString()
        val existing = _doctors.value.find { it.name.trim() == name.trim() && it.specialty.trim() == specialty.trim() }
        if (existing != null) {
            viewModelScope.launch {
                _eventFlow.emit(DashboardEvent.ShowToast("الطبيب موجود مسبقاً ⚠️"))
            }
            return
        }

        val doc = DoctorItem(
            id = docId,
            name = name,
            specialty = specialty,
            workingHours = workingHours
        )
        viewModelScope.launch {
            medicalRepository.addDoctor(ownerId, doc).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تمت إضافة الطبيب بنجاح 🩺"))
            }.onFailure {
                _eventFlow.emit(DashboardEvent.ShowToast("حدث خطأ أثناء الإضافة"))
            }
        }
    }

    fun deleteDoctor(id: String) {
        viewModelScope.launch {
            medicalRepository.deleteDoctor(id).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تم حذف الطبيب 🗑️"))
            }.onFailure {
                _eventFlow.emit(DashboardEvent.ShowToast("حدث خطأ أثناء الحذف"))
            }
        }
    }

    fun addMedicalService(
        title: String,
        priceYer: Double,
        description: String = "",
        imageUrl: String = "",
        category: String = "MEDICAL",
        isAvailable: Boolean = true,
        isOffer: Boolean = false,
        discountPercent: Int = 0,
        oldPriceYer: Double = 0.0,
        unit: String = ""
    ) {
        viewModelScope.launch {
            if (title.isBlank()) {
                _eventFlow.emit(DashboardEvent.ShowToast("يرجى إدخال اسم الخدمة الطبية"))
                return@launch
            }
            val service = ProductItemEntity(
                ownerId = ownerId,
                title = title,
                priceYer = priceYer,
                description = description,
                imageUrl = imageUrl,
                category = category.ifBlank { "MEDICAL" },
                isAvailable = isAvailable,
                isOffer = isOffer || discountPercent > 0,
                discountPercent = discountPercent.coerceIn(0, 99),
                oldPriceYer = oldPriceYer.coerceAtLeast(0.0),
                unit = unit
            )
            productsRepository.addProduct(service).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تمت إضافة الخدمة الطبية 💊"))
            }.onFailure { e ->
                _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "فشل إضافة الخدمة"))
            }
        }
    }

    fun deleteMedicalService(id: String) {
        viewModelScope.launch {
            productsRepository.deleteProduct(id).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تم حذف الخدمة الطبية 🗑️"))
            }.onFailure { e ->
                _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "فشل حذف الخدمة الطبية"))
            }
        }
    }

    fun updateMedicalService(product: ProductItemEntity) {
        viewModelScope.launch {
            productsRepository.updateProduct(product).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تم تحديث الخدمة الطبية بنجاح ✅"))
            }.onFailure { e ->
                _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "فشل تحديث الخدمة الطبية"))
            }
        }
    }

    fun replyToReview(reviewId: String, replyText: String) {
        viewModelScope.launch {
            ratingsRepository.replyToRating(reviewId, replyText).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تم الرد على تقييم المريض بنجاح ✅"))
            }.onFailure { e ->
                _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "تعذر حفظ الرد"))
            }
        }
    }

    fun updateProfile(
        name: String,
        cityArea: String,
        description: String,
        workingHours: String,
        isAvailable: Boolean,
        photoUrl: String? = null,
        coverUrl: String? = null,
        phone: String? = null,
        latitude: Double? = null,
        longitude: Double? = null
    ) {
        viewModelScope.launch {
            dashboardRepository.updateBusinessProfile(
                ownerId = ownerId,
                role = "MEDICAL",
                name = name,
                cityArea = cityArea,
                description = description,
                workingHours = workingHours,
                isAvailable = isAvailable,
                photoUrl = photoUrl,
                coverUrl = coverUrl,
                phone = phone,
                latitude = latitude,
                longitude = longitude
            ).onSuccess {
                _eventFlow.emit(DashboardEvent.ShowToast("تم تحديث بيانات المركز بنجاح ✅"))
            }.onFailure { e ->
                _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "فشل تحديث البيانات"))
            }
        }
    }

    fun changePassword(oldPass: String, newPass: String) {
        viewModelScope.launch {
            dashboardRepository.changeBusinessPassword(ownerId, "MEDICAL", oldPass, newPass)
                .onSuccess { _eventFlow.emit(DashboardEvent.ShowToast("تم تغيير كلمة المرور بنجاح 🔑")) }
                .onFailure { e -> _eventFlow.emit(DashboardEvent.ShowToast(e.localizedMessage ?: "فشل تغيير كلمة المرور")) }
        }
    }

    fun dispose() {
        onCleared()
    }

    override fun onCleared() {
        super.onCleared()
        loadJob?.cancel()
        loadJob = null
        doctorsJob?.cancel()
        doctorsJob = null
    }
}
