// [تحسين مدمج] محول بيانات الخريطة التفاعلية Leaflet WebView
package com.example.ui.screens.map.utils

import com.example.data.PropertyEntity
import com.example.ui.*
import com.example.data.ProviderEntity
import com.example.data.StoreEntity
import com.example.utils.getPropertyCoords
import com.example.utils.getProviderCoords
import com.example.utils.getStoreCoords
import org.json.JSONArray
import org.json.JSONObject

/**
 * 🗺️ MapJsonBuilder
 * // [تحسين مدمج] نشط ويعمل لبناء كائنات JSON للعلامات التفاعلية على خريطة Leaflet
 * Builds structured JSON strings for Leaflet WebView markers.
 */
object MapJsonBuilder {

    const val MAX_PER_TYPE = 400

    private fun idTokens(id: String) = id.lowercase().split('_', '-', ' ', '.').filter { it.isNotEmpty() }.toSet()
    private fun hasId(id: String, vararg keys: String): Boolean = idTokens(id).any { it in keys }

    fun buildMarkersJson(
        nearbyProviders: List<ProviderEntity>,
        nearbyStores: List<StoreEntity>,
        nearbyProperties: List<PropertyEntity>,
        dynamicOffsets: Map<String, Pair<Double, Double>>,
        safeUserLat: Double,
        safeUserLng: Double
    ): String {
        return buildMarkersJsonArray(
            nearbyProviders,
            nearbyStores,
            nearbyProperties,
            dynamicOffsets,
            safeUserLat,
            safeUserLng
        )
    }

    fun buildMarkersJsonArray(
        nearbyProviders: List<ProviderEntity>,
        nearbyStores: List<StoreEntity>,
        nearbyProperties: List<PropertyEntity>,
        dynamicOffsets: Map<String, Pair<Double, Double>>,
        safeUserLat: Double,
        safeUserLng: Double
    ): String {
        val jsonArray = JSONArray()

        // 1. Providers
        nearbyProviders.forEach { p ->
            val baseCoords = getProviderCoords(p)
            val rawLat = baseCoords.first
            val rawLng = baseCoords.second
            if (rawLat.isNaN() || rawLng.isNaN()) return@forEach
            val isApproximate = p.latitude == 0.0 || p.longitude == 0.0

            val categoryEmoji = p.categoryId.let { cid ->
                when {
                    hasId(cid, "spaka", "plumber") || p.profession.contains("سباك") -> "🔧"
                    hasId(cid, "kahraba", "electric") || p.profession.contains("كهربا") -> "⚡"
                    hasId(cid, "solar") || p.profession.contains("طاقة") -> "☀️"
                    hasId(cid, "dehan", "paint") || p.profession.contains("دهان") -> "🎨"
                    hasId(cid, "hadada") || p.profession.contains("حداد") -> "🔨"
                    hasId(cid, "ac", "tabreed") || p.profession.contains("تكييف") -> "❄️"
                    hasId(cid, "carpentry", "najjara") || p.profession.contains("نجار") -> "🪚" // قبل car لتفادي التطابق الجزئي
                    hasId(cid, "car", "mechanic") || p.profession.contains("ميكانيك") -> "🚗"
                    else -> "👷"
                }
            }

            val pSpec = p.customCategoryName.ifEmpty { p.specialization.ifEmpty { p.profession } }
            val cleanSpec = if (pSpec.isBlank()) "فني صيانة معتمد" else pSpec

            val obj = JSONObject().apply {
                put("id", p.id)
                put("type", "PROVIDER")
                put("name", p.name.ifBlank { "فني دليل اليمن" })
                put("lat", rawLat)
                put("lng", rawLng)
                put("isApprox", isApproximate)
                put("emoji", categoryEmoji)
                put("spec", cleanSpec)
                put("phone", p.phone)
                put("rating", if (p.rating > 0) String.format(java.util.Locale.US, "%.1f", p.rating) else "جديد")
                put("status", if (p.isAvailable) "متاح لاستقبال الطلبات 🟢" else "مشغول حالياً 🟡")
                put("badgeColor", "#2563EB") // أزرق للفنيين
                put("serviceCategory", "فنيون صيانة")
            }
            jsonArray.put(obj)
        }

        // 2. Stores & Medical Centers & Restaurants
        nearbyStores.forEach { s ->
            val coords = getStoreCoords(s)
            val rawLat = coords.first
            val rawLng = coords.second
            if (rawLat.isNaN() || rawLng.isNaN()) return@forEach

            val isMedical = s.sectionId.contains("medical") || s.categoryId.contains("medical") || s.categoryId.contains("pharmacy") || s.medicalLicenseNo.isNotBlank() || s.name.contains("طبي") || s.name.contains("مستشفى") || s.name.contains("عيادة") || s.name.contains("صيدلية")
            val isRestaurant = !isMedical && (s.sectionId.contains("restaurant") || s.categoryId.contains("restaurant") || s.name.contains("مطعم") || s.name.contains("مأكولات") || s.name.contains("كافيه") || s.name.contains("شاورما"))

            val emoji = when {
                isMedical -> "🏥"
                isRestaurant -> "🍔"
                s.sectionId.contains("supermarket") || s.name.contains("بقالة") || s.name.contains("هايبر") -> "🛒"
                else -> "🏪"
            }

            val isApproximate = s.latitude == 0.0 || s.longitude == 0.0

            val (badgeColor, categoryLabel) = when {
                isMedical -> Pair("#EF4444", "مراكز طبية وصيدليات") // أحمر للمراكز الطبية
                isRestaurant -> Pair("#F59E0B", "مطاعم وكافيهات") // برتقالي للمطاعم
                else -> Pair("#10B981", "متاجر وأسواق") // أخضر للمتاجر
            }

            val cleanDesc = s.description.ifBlank { if (isMedical) "مركز طبي / صيدلية معتمدة" else "محل / متجر معتمد" }.take(60)

            val obj = JSONObject().apply {
                put("id", s.id)
                put("type", "STORE")
                put("name", s.name.ifBlank { "متجر معتمد" })
                put("lat", rawLat)
                put("lng", rawLng)
                put("isApprox", isApproximate)
                put("emoji", emoji)
                put("spec", cleanDesc)
                put("phone", s.phone)
                put("rating", if (s.rating > 0) String.format(java.util.Locale.US, "%.1f", s.rating) else "جديد")
                put("status", if (s.isActive) "مفتوح ويستقبل الطلبات 🟢" else "مغلق حالياً 🔴")
                put("badgeColor", badgeColor)
                put("serviceCategory", categoryLabel)
            }
            jsonArray.put(obj)
        }

        // 3. Properties
        nearbyProperties.forEach { pr ->
            val coords = getPropertyCoords(pr)
            val rawLat = coords.first
            val rawLng = coords.second
            if (rawLat.isNaN() || rawLng.isNaN()) return@forEach

            val isApproximate = pr.latitude == 0.0 || pr.longitude == 0.0
            val priceFormatted = if (pr.price > 0) "${pr.price} ${pr.currency.ifEmpty { "ريال" }}" else "حسب الاتفاق"
            val cleanDesc = pr.description.ifBlank { "عقار معروض" }.take(60)

            val obj = JSONObject().apply {
                put("id", pr.id)
                put("type", "PROPERTY")
                put("name", pr.title.ifBlank { "عقار معروض" })
                put("lat", rawLat)
                put("lng", rawLng)
                put("isApprox", isApproximate)
                put("emoji", "🏠")
                put("spec", "$cleanDesc ($priceFormatted)")
                put("phone", pr.phone)
                put("rating", "—")
                put("status", "معروض للإيجار / البيع 🟢")
                put("badgeColor", "#8B5CF6")
                put("serviceCategory", "عقارات وشقق")
            }
            jsonArray.put(obj)
        }

        android.util.Log.d("MapJsonBuilder", "Built ${jsonArray.length()} markers for Leaflet Map (Providers: ${nearbyProviders.size}, Stores: ${nearbyStores.size}, Properties: ${nearbyProperties.size})")
        return jsonArray.toString()
    }
}
