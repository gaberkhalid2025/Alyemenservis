package com.example.ui.screens.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.screens.dashboard.components.UnifiedProfileSection
import com.example.ui.screens.dashboard.components.UnifiedSettingsSection
import com.example.utils.VisualThemePalette

@Composable
fun TabProfileEdit(
    name: String,
    phone: String,
    cityArea: String,
    description: String,
    workingHours: String = "",
    photoUrl: String = "",
    coverUrl: String = "",
    isAvailable: Boolean = true,
    rating: Double = 5.0,
    reviewCount: Int = 0,
    latitude: Double = 0.0,
    longitude: Double = 0.0,
    themeColors: VisualThemePalette,
    onChangePhoto: ((String) -> Unit)? = null,
    onChangeCover: ((String) -> Unit)? = null,
    onSaveLocation: ((Double, Double) -> Unit)? = null,
    onSaveProfile: (name: String, phone: String, cityArea: String, description: String, workingHours: String, isAvailable: Boolean) -> Unit,
    onChangePassword: (oldPass: String, newPass: String) -> Unit
) {
    var currentPhoto by remember(photoUrl) { mutableStateOf(photoUrl) }
    var currentCover by remember(coverUrl) { mutableStateOf(coverUrl) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        UnifiedProfileSection(
            title = name,
            subtitle = description,
            phone = phone,
            cityArea = cityArea,
            photoUrl = currentPhoto,
            coverUrl = currentCover,
            rating = rating,
            reviewCount = reviewCount,
            isAvailable = isAvailable,
            themeColors = themeColors,
            onChangePhoto = onChangePhoto?.let { cb ->
                { newUrl: String ->
                    currentPhoto = newUrl
                    cb(newUrl)
                }
            },
            onChangeCover = onChangeCover?.let { cb ->
                { newUrl: String ->
                    currentCover = newUrl
                    cb(newUrl)
                }
            }
        )

        UnifiedSettingsSection(
            name = name,
            phone = phone,
            cityArea = cityArea,
            description = description,
            workingHours = workingHours,
            isAvailable = isAvailable,
            latitude = latitude,
            longitude = longitude,
            themeColors = themeColors,
            onSaveProfile = onSaveProfile,
            onSaveLocation = onSaveLocation,
            onChangePassword = onChangePassword
        )
    }
}
