@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.ui.screens.home

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.*
import com.example.ui.components.AdminCustomBannerView
import com.example.ui.components.BannerSliderView
import com.example.utils.VisualThemePalette

import com.example.data.repositories.*
import com.example.ui.screens.home.sections.*
import com.example.*
import com.example.ui.dialogs.JobApplicationDialog
import com.example.VoiceManager

/**
 * 🏠 ServicesBrowserLayout - الشاشة الرئيسية لتصفح الخدمات والمتاجر باليمن
 * مفككة ومبنية وفق معمارية Clean Architecture و MVVM النظيفة (<250 سطر)
 */
@Composable
fun ServicesBrowserLayout(
    viewModel: MainViewModel,
    themeColors: VisualThemePalette,
    activeSectionIdForCreation: String,
    onActiveSectionIdForCreationChange: (String) -> Unit,
    preselectedRegistrationType: String,
    onPreselectedRegistrationTypeChange: (String) -> Unit,
    onChatOpen: (String) -> Unit
) {
    val context = LocalContext.current
    val appContext = context.applicationContext

    val categories by viewModel.categories.collectAsState()
    val allProviders by viewModel.providers.collectAsState()
    val filteredProviders by viewModel.filteredProviders.collectAsState()
    val isProvidersLoading by viewModel.isProvidersLoading.collectAsState()
    val selectedCategory by viewModel.selectedCategoryId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val stores by viewModel.stores.collectAsState()
    val properties by viewModel.properties.collectAsState()
    val products by viewModel.products.collectAsState()
    val isVipOnly by viewModel.filterVipOnly.collectAsState()
    val isAvailableOnly by viewModel.filterAvailableOnly.collectAsState()
    val citiesList by viewModel.cities.collectAsState()
    val activeCityId by viewModel.filterCityId.collectAsState()
    val radiusKm by viewModel.maxKmRadius.collectAsState()
    val neighborFilter by viewModel.filterNeighborhoodName.collectAsState()
    val phoneOrNameFilter by viewModel.phoneOrNameFilter.collectAsState()
    val bannersList by viewModel.banners.collectAsState()
    val settingsState by viewModel.settings.collectAsState()
    val paymentWallets by viewModel.paymentWallets.collectAsState()

    val filteredStores by viewModel.filteredStores.collectAsState()
    val filteredProperties by viewModel.filteredProperties.collectAsState()

    var showFiltersPanel by remember { mutableStateOf(false) }
    var selectedStoreForDetails by remember { mutableStateOf<StoreEntity?>(null) }
    var selectedPropertyForDetails by remember { mutableStateOf<PropertyEntity?>(null) }
    var selectedJobForDetails by remember { mutableStateOf<JobEntity?>(null) }
    var showJobApplicationForJob by remember { mutableStateOf<JobEntity?>(null) }
    var providersLimit by remember { mutableStateOf(10) }
    val activeTabName by viewModel.activeBrowserTab.collectAsState()

    val activeTabs = remember(settingsState) {
        val list = mutableListOf("الرئيسية")
        if (settingsState.isStoresEnabled) list.add("المحلات والمتاجر")
        list.add("المطاعم والكافيهات")
        list.add("المراكز الطبية")
        if (settingsState.isPropertiesEnabled) list.add("العقارات")
        list.add("إعلانات الوظائف")
        list.add("المفضلة")
        list.toList()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (activeTabName == "الرئيسية") {
            // 1. Top Custom Banner
            if (settingsState.bannerEnabled && settingsState.bannerLocation == "TOP") {
                item {
                    AdminCustomBannerView(settingsState = settingsState, themeColors = themeColors)
                }
            }

            // 2. Hero Promotional Banner Carousel (سلايدر العروض والشركاء)
            item {
                BannerSliderView(banners = bannersList, themeColors = themeColors) { catTarget ->
                    if (catTarget.isNotEmpty()) viewModel.selectCategory(catTarget)
                }
            }

            // 3. Floating Glassmorphic Search & Filter Bar (شريط البحث الصوتي والذكي)
            item {
                val isFilterActive = phoneOrNameFilter.isNotEmpty() || neighborFilter.isNotEmpty() || isVipOnly || isAvailableOnly
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateToScreen(AppScreens.UNIFIED_SEARCH) }
                ) {
                    ServicesSearchBar(
                        searchQuery = searchQuery,
                        onSearchQueryChange = { 
                            viewModel.updateSearchQuery(it)
                            viewModel.navigateToScreen(AppScreens.UNIFIED_SEARCH)
                        },
                        isFilterActive = isFilterActive,
                        onFilterClick = { showFiltersPanel = true },
                        isSpeechSearchEnabled = settingsState.isSpeechSearchEnabled,
                        onVoiceClick = {
                            VoiceManager.onHear?.invoke { heardText ->
                                viewModel.updateSearchQuery(heardText)
                                viewModel.navigateToScreen(AppScreens.UNIFIED_SEARCH)
                            }
                        },
                        themeColors = themeColors
                    )
                }
            }

            // 4 & 5: Category Grid (4x2) + Golden Partner CTA
            item {
                CategoryGridSection(
                    onSelectSection = { secId ->
                        when (secId) {
                            "stores" -> viewModel.setActiveBrowserTab("المحلات والمتاجر")
                            "restaurants" -> viewModel.setActiveBrowserTab("المطاعم والكافيهات")
                            "medical" -> viewModel.setActiveBrowserTab("المراكز الطبية")
                            "properties" -> viewModel.setActiveBrowserTab("العقارات")
                            "jobs" -> viewModel.setActiveBrowserTab("إعلانات الوظائف")
                            "technicians" -> {
                                viewModel.selectCategory("")
                            }
                            else -> viewModel.setActiveBrowserTab("المحلات والمتاجر")
                        }
                    },
                    onSelectTechnicianSubCategory = { subCatName ->
                        viewModel.updateSearchQuery(subCatName)
                    },
                    topRatedProviders = emptyList(),
                    topRatedStores = stores.sortedByDescending { it.rating },
                    onProviderClick = { prov ->
                        viewModel.selectedProvider = prov
                        viewModel.navigateTo("DYNAMIC_PROFILE")
                    },
                    onStoreClick = { store ->
                        selectedStoreForDetails = store
                    },
                    onJoinAsProviderClick = {
                        viewModel.setTargetRegistrationType("provider")
                        viewModel.navigateTo(AppScreens.REGISTER_FORM)
                    },
                    themeColors = themeColors,
                    onOpenChat = onChatOpen
                )
            }
        } else {
            // Back button to Home when a section tab is active
            item {
                Surface(
                    onClick = { viewModel.setActiveBrowserTab("الرئيسية") },
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("←", color = themeColors.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("العودة للرئيسية", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("·", color = Color.Gray, fontSize = 12.sp)
                        Text(activeTabName, color = themeColors.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5. Main Tab Content
        item {
            when (activeTabName) {
                "المفضلة" -> {
                    FavoritesScreenLayout(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onBackClick = { viewModel.setActiveBrowserTab("الرئيسية") },
                        onOpenProviderDetails = {
                            viewModel.selectedProvider = it
                            viewModel.navigateTo("DYNAMIC_PROFILE")
                        },
                        onOpenStoreDetails = { selectedStoreForDetails = it },
                        onOpenPropertyDetails = { selectedPropertyForDetails = it },
                        onOpenChat = onChatOpen
                    )
                }
                "المحلات والمتاجر", "المحلات", settingsState.storesTabName -> {
                    StoresSectionView(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onStoreClick = { 
                            viewModel.selectedStore = it
                            viewModel.navigateTo("STORE_DETAILS")
                        },
                        onCreateStoreClick = {
                            viewModel.setTargetRegistrationType("store")
                            viewModel.navigateTo(AppScreens.REGISTER_FORM)
                        }
                    )
                }
                "المطاعم والكافيهات", "المطاعم" -> {
                    RestaurantsSectionView(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onStoreClick = { 
                            viewModel.selectedStore = it
                            viewModel.navigateTo("STORE_DETAILS")
                        },
                        onCreateRestaurantClick = {
                            viewModel.setTargetRegistrationType("restaurant")
                            viewModel.navigateTo(AppScreens.REGISTER_FORM)
                        }
                    )
                }
                "المراكز الطبية", "المراكز" -> {
                    MedicalCentersSectionView(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onStoreClick = { 
                            viewModel.selectedStore = it
                            viewModel.navigateTo("STORE_DETAILS")
                        },
                        onCreateMedicalClick = {
                            viewModel.setTargetRegistrationType("medical")
                            viewModel.navigateTo(AppScreens.REGISTER_FORM)
                        }
                    )
                }
                "العقارات", settingsState.propertiesTabName -> {
                    PropertiesSectionView(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onPropertyClick = { selectedPropertyForDetails = it },
                        onCreatePropertyClick = {
                            viewModel.setTargetRegistrationType("property")
                            viewModel.navigateTo(AppScreens.REGISTER_FORM)
                        }
                    )
                }
                "إعلانات الوظائف", "الوظائف" -> {
                    JobsSectionView(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        onJobClick = { selectedJobForDetails = it },
                        onCreateJobClick = {
                            viewModel.setTargetRegistrationType("job")
                            viewModel.navigateTo(AppScreens.REGISTER_FORM)
                        }
                    )
                }
                else -> {
                    val effectiveDisplayProviders = if (searchQuery.isBlank() && 
                        (selectedCategory.isNullOrBlank() || selectedCategory == "ALL" || selectedCategory == "الكل")) {
                        allProviders
                    } else {
                        filteredProviders
                    }

                    ServicesBrowserMainContent(
                        viewModel = viewModel,
                        themeColors = themeColors,
                        displayProviders = effectiveDisplayProviders,
                        displayStores = filteredStores,
                        displayProperties = filteredProperties,
                        isProvidersLoading = isProvidersLoading,
                        categories = categories,
                        selectedCategoryId = selectedCategory,
                        onCategorySelected = { viewModel.selectCategory(it ?: "") },
                        providersLimit = providersLimit,
                        onLoadMore = { providersLimit += 10 },
                        onStoreClick = { 
                            viewModel.selectedStore = it
                            viewModel.navigateTo("STORE_DETAILS")
                        },
                        onPropertyClick = { selectedPropertyForDetails = it },
                        onChatOpen = onChatOpen
                    )
                }
            }
        }
    }

    // Dialogs & Payment Sheets
    if (showFiltersPanel) {
        FilterPanelDialog(
            cities = citiesList,
            selectedCityId = activeCityId ?: "",
            onSelectCity = { viewModel.setCityFilter(it) },
            isVipOnly = isVipOnly,
            onToggleVip = { viewModel.toggleVipFilter() },
            isAvailableOnly = isAvailableOnly,
            onToggleAvailable = { viewModel.toggleAvailableFilter() },
            radiusKm = radiusKm,
            onRadiusChange = { viewModel.setRadiusKm(it) },
            neighborhood = neighborFilter,
            onNeighborhoodChange = { viewModel.setNeighborhoodFilter(it) },
            themeColors = themeColors,
            onDismiss = { showFiltersPanel = false }
        )
    }

    selectedStoreForDetails?.let { store ->
        StoreQuickDetailsDialog(
            store = store,
            context = context,
            themeColors = themeColors,
            onDismiss = { selectedStoreForDetails = null },
            onOpenDetails = {
                val storeToOpen = store
                selectedStoreForDetails = null
                viewModel.selectedStore = storeToOpen
                viewModel.navigateTo("STORE_DETAILS")
            }
        )
    }

    selectedPropertyForDetails?.let { prop ->
        PropertyQuickDetailsDialog(
            property = prop,
            context = context,
            themeColors = themeColors,
            onDismiss = { selectedPropertyForDetails = null }
        )
    }

    selectedJobForDetails?.let { job ->
        JobQuickDetailsDialog(
            job = job,
            context = context,
            themeColors = themeColors,
            onDismiss = { selectedJobForDetails = null },
            onApply = {
                val targetJob = job
                selectedJobForDetails = null
                showJobApplicationForJob = targetJob
            }
        )
    }

    showJobApplicationForJob?.let { job ->
        JobApplicationDialog(
            viewModel = viewModel,
            themeColors = themeColors,
            jobTitle = job.title,
            onDismiss = { showJobApplicationForJob = null }
        )
    }
}
