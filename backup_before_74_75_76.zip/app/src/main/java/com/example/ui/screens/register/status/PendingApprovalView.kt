package com.example.ui.screens.register.status

import androidx.compose.foundation.BorderStroke
import com.example.ui.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.VisualThemePalette

/**
 * ⏳ PendingApprovalView - عرض شاشة طلب قيد المراجعة والتدقيق الإداري
 */
@Composable
fun PendingApprovalView(
    title: String = "طلب انضمامك قيد المراجعة ⏳",
    message: String = "تم استلام طلبك بنجاح وهو قيد التدقيق الإداري والتأكد من المستندات. فور الموافقة سيتم تفعيل حسابك فوراً.",
    detailsTitle: String = "📋 تفاصيل الطلب المقدم:",
    detailsList: List<Pair<String, String>>,
    onCancelRequest: () -> Unit,
    themeColors: VisualThemePalette,
    modifier: Modifier = Modifier,
    onRefreshStatus: (() -> Unit)? = null
) {
    var showCancelConfirmDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = themeColors.surface),
        border = BorderStroke(1.5.dp, Color(0xFFF59E0B))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(Color(0xFFF59E0B).copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "⏳", fontSize = 28.sp)
            }

            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFF59E0B),
                textAlign = TextAlign.Center
            )

            Text(
                text = message,
                fontSize = 11.5.sp,
                color = themeColors.textSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 17.sp
            )

            HorizontalDivider(color = themeColors.border.copy(alpha = 0.3f), thickness = 1.dp)

            Card(
                colors = CardDefaults.cardColors(containerColor = themeColors.background.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(detailsTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF59E0B))
                    detailsList.forEach { (key, value) ->
                        Text("• $key: $value", fontSize = 11.sp, color = themeColors.textPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (onRefreshStatus != null) {
                Button(
                    onClick = onRefreshStatus,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text("🔄 تحديث حالة الطلب والتحقق", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Button(
                onClick = { showCancelConfirmDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Text("❌ إلغاء والعودة لشاشة التسجيل", color = Color.White, fontSize = 11.sp)
            }
        }
    }

    if (showCancelConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showCancelConfirmDialog = false },
            title = { Text("تأكيد إلغاء الطلب", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = { Text("هل أنت متأكد من إلغاء طلب الانضمام الحالي والعودة إلى شاشة التسجيل؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelConfirmDialog = false
                        onCancelRequest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("نعم، إلغاء الطلب", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelConfirmDialog = false }) {
                    Text("تراجع")
                }
            }
        )
    }
}
