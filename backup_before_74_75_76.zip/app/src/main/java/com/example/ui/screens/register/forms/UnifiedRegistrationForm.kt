@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.ui.screens.register.forms

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.domain.YemenCities
import com.example.utils.VisualThemePalette

/**
 * 📝 UnifiedRegistrationForm - استمارة التسجيل الموحدة والمخصصة بالكامل لكل فئة من الفئات الـ 8
 * مطابقة 100% لكافة الحقول والشروط المطلوبة وبدون أي حقل بريد إلكتروني.
 */
@Composable
fun UnifiedRegistrationForm(
    role: String,
    themeColors: VisualThemePalette,
    onRegistrationSuccess: (Map<String, String>) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val normalizedRole = role.uppercase()

    // الحقول الأساسية المشتركة
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("صنعاء") }
    var address by remember { mutableStateOf("") }

    // 📍 الموقع الجغرافي والإحداثيات
    var gpsCoords by remember { mutableStateOf("") }
    var latitude by remember { mutableStateOf(15.3694) }
    var longitude by remember { mutableStateOf(44.1910) }
    var isLocating by remember { mutableStateOf(false) }
    var locationDetected by remember { mutableStateOf(false) }
    var locationErrorText by remember { mutableStateOf<String?>(null) }

    var showMapPicker by remember { mutableStateOf(false) }
    var showManualCoords by remember { mutableStateOf(false) }

    fun applyPickedCoordinates(lat: Double, lng: Double, summary: String = "") {
        latitude = lat
        longitude = lng
        gpsCoords = "${String.format(java.util.Locale.US, "%.5f", lat)},${String.format(java.util.Locale.US, "%.5f", lng)}"
        locationDetected = true
        locationErrorText = null
        if (summary.isNotBlank() && address.isBlank()) {
            address = summary
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun fetchDeviceLocation() {
        isLocating = true
        locationErrorText = null
        try {
            val locationManager = context.getSystemService(android.content.Context.LOCATION_SERVICE) as? android.location.LocationManager
            if (locationManager == null) {
                locationErrorText = "خدمة الموقع غير متاحة في هذا الجهاز — حدد موقعك من الخريطة"
                isLocating = false
                return
            }
            var bestLoc: android.location.Location? = null
            val providers = locationManager.getProviders(true)
            for (p in providers) {
                val l = locationManager.getLastKnownLocation(p) ?: continue
                if (bestLoc == null || l.accuracy < bestLoc.accuracy) {
                    bestLoc = l
                }
            }
            val nowMs = System.currentTimeMillis()
            if (bestLoc != null && (nowMs - bestLoc.time) <= 10 * 60 * 1000L) {
                applyPickedCoordinates(bestLoc.latitude, bestLoc.longitude)
                isLocating = false
                return
            }
            val activeProvider = when {
                locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ->
                    android.location.LocationManager.GPS_PROVIDER
                locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) ->
                    android.location.LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (activeProvider != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                locationManager.getCurrentLocation(
                    activeProvider,
                    null,
                    context.mainExecutor
                ) { fresh ->
                    isLocating = false
                    if (fresh != null) {
                        applyPickedCoordinates(fresh.latitude, fresh.longitude)
                    } else if (bestLoc != null) {
                        applyPickedCoordinates(bestLoc.latitude, bestLoc.longitude)
                        locationErrorText = "تم استخدام آخر موقع معروف — يمكنك تعديله من الخريطة"
                    } else {
                        locationErrorText = "تعذر التقاط إشارة GPS حالياً — يرجى التحديد من الخريطة أو إدخال الإحداثيات"
                    }
                }
            } else if (bestLoc != null) {
                applyPickedCoordinates(bestLoc.latitude, bestLoc.longitude)
                locationErrorText = "تم استخدام آخر موقع محفوظ — يُنصح بتأكيده عبر الخريطة"
                isLocating = false
            } else {
                isLocating = false
                locationErrorText = "لم تتوفر إشارة GPS بعد — استخدم زر الخريطة لتحديد موقعك بدقة"
            }
        } catch (e: Exception) {
            isLocating = false
            locationErrorText = "تعذر جلب الموقع: ${e.message}"
        }
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fine = permissions[android.Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarse = permissions[android.Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fine || coarse) {
            fetchDeviceLocation()
        } else {
            isLocating = false
            locationErrorText = "يرجى منح إذن الموقع لتحديد إحداثياتك بدقة على الخريطة"
        }
    }

    // حقول إضافية مخصصة حسب الفئة
    var specialization by remember { mutableStateOf("") } // المهنة / التخصص / نوع النشاط / التخصصات
    var experienceYears by remember { mutableStateOf("") } // سنوات الخبرة
    var entityName by remember { mutableStateOf("") } // اسم المتجر / المطعم / المركز / المكتب / الشركة
    var workingHours by remember { mutableStateOf("") } // ساعات العمل
    var notesOrDescription by remember { mutableStateOf("") } // نبذة / وصف
    var extraOption1 by remember { mutableStateOf(false) } // هل يوفر توصيل؟ / هل يوفر طوارئ؟
    var cvUrlOrQualification by remember { mutableStateOf("") } // المؤهل العلمي أو رابط السيرة الذاتية

    // الصور والشعارات (اختيارية)
    var imageUri by remember { mutableStateOf("") }
    var idCardUri by remember { mutableStateOf("") }

    // التحكم في إظهار كلمات المرور
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var agreedToTerms by remember { mutableStateOf(false) }

    // حالات التنبيه والأخطاء
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    LaunchedEffect(isSubmitting) {
        if (isSubmitting) {
            kotlinx.coroutines.delay(15_000L)
            isSubmitting = false
        }
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) imageUri = uri.toString()
    }

    val idCardPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) idCardUri = uri.toString()
    }

    val cities = YemenCities.MAIN_CITIES
    var expandedCity by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = themeColors.surface),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 🎯 رأس الاستمارة
            val headerTitle = when (normalizedRole) {
                "CLIENT" -> "استمارة تسجيل العميل (مستخدم عادي)"
                "PROVIDER", "TECHNICIAN" -> "استمارة انضمام الفني / مقدم الخدمة"
                "JOB_SEEKER" -> "استمارة المتقدم للوظائف (باحث عن عمل)"
                "STORE" -> "استمارة انضمام المتجر / المحل"
                "RESTAURANT" -> "استمارة انضمام المطعم / الكافيه"
                "MEDICAL" -> "استمارة انضمام المركز الطبي / الصيدلية"
                "PROPERTY" -> "استمارة انضمام المكتب العقاري / العقارات"
                "JOB", "JOB_POSTER" -> "استمارة تسجيل معلن الوظائف (شركة / منشأة)"
                else -> "استمارة التسجيل والانضمام"
            }

            Text(
                text = headerTitle,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = themeColors.accent
            )

            Text(
                text = "جميع الحقول بعلامة (*) إجبارية وسيتم مراجعتها من قِبل الإدارة.",
                fontSize = 11.sp,
                color = Color.LightGray
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f), thickness = 1.dp)

            if (errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEF4444).copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, Color(0xFFEF4444)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⚠️ $errorMessage",
                        color = Color(0xFFEF4444),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // 📸 مربع تحميل الشعار أو الصورة (إذا كانت مدعومة لهذه الفئة)
            if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER")) {
                val photoLabel = when (normalizedRole) {
                    "PROVIDER", "TECHNICIAN" -> "الصورة الشخصية (اختياري)"
                    "STORE" -> "شعار المتجر (اختياري)"
                    "RESTAURANT" -> "شعار المطعم (اختياري)"
                    "MEDICAL" -> "شعار المركز / الصيدلية (اختياري)"
                    "PROPERTY" -> "شعار المكتب العقاري (اختياري)"
                    "JOB", "JOB_POSTER" -> "شعار الشركة (اختياري)"
                    else -> "صورة الحساب / الشعار (اختياري)"
                }

                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                    border = BorderStroke(1.dp, themeColors.accent.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (imageUri.isNotBlank()) {
                                AsyncImage(
                                    model = Uri.parse(imageUri),
                                    contentDescription = photoLabel,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                                )
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = themeColors.accent.copy(alpha = 0.2f),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.AddAPhoto, contentDescription = null, tint = themeColors.accent)
                                    }
                                }
                            }
                            Column {
                                Text(photoLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(if (imageUri.isNotBlank()) "تم اختيار الصورة بنجاح ✅" else "انقر للاختيار من المعرض", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Button(
                            onClick = { imagePickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeColors.accent, contentColor = Color.Black),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(if (imageUri.isNotBlank()) "تغيير 🔄" else "اختيار 📷", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 1️⃣ حقل الاسم الأساسي
            val nameFieldLabel = when (normalizedRole) {
                "STORE", "RESTAURANT", "PROPERTY" -> "الاسم الثلاثي للمالك *"
                "MEDICAL" -> "الاسم الثلاثي للمدير *"
                "JOB", "JOB_POSTER" -> "الاسم الثلاثي للمسؤول *"
                else -> "الاسم الثلاثي *"
            }
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text(nameFieldLabel, fontSize = 12.sp) },
                placeholder = { Text("مثال: محمد علي الأحمدي", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 2️⃣ حقل اسم المنشأة / المتجر / المركز / الشركة (للفئات التجارية)
            if (normalizedRole in listOf("STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER")) {
                val entityLabel = when (normalizedRole) {
                    "STORE" -> "اسم المتجر *"
                    "RESTAURANT" -> "اسم المطعم / الكافيه *"
                    "MEDICAL" -> "اسم المركز / الصيدلية *"
                    "PROPERTY" -> "اسم المكتب العقاري *"
                    "JOB", "JOB_POSTER" -> "اسم الشركة *"
                    else -> "اسم المنشأة *"
                }
                OutlinedTextField(
                    value = entityName,
                    onValueChange = { entityName = it },
                    label = { Text(entityLabel, fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 3️⃣ حقل رقم الهاتف
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("رقم الهاتف *", fontSize = 12.sp) },
                placeholder = { Text("77XXXXXXX أو 73XXXXXXX (9 أرقام)", fontSize = 11.sp) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 4️⃣ حقل كلمة المرور
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("كلمة المرور *", fontSize = 12.sp) },
                placeholder = { Text("7 خانات على الأقل (حروف وأرقام)", fontSize = 11.sp) },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = null,
                            tint = themeColors.accent
                        )
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 5️⃣ حقل تأكيد كلمة المرور
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("تأكيد كلمة المرور *", fontSize = 12.sp) },
                placeholder = { Text("إعادة كتابة كلمة المرور", fontSize = 11.sp) },
                visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                        Icon(
                            imageVector = if (confirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = null,
                            tint = themeColors.accent
                        )
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 6️⃣ حقل التخصص / النشاط / المجال
            if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "JOB_SEEKER", "STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER")) {
                val specLabel = when (normalizedRole) {
                    "PROVIDER", "TECHNICIAN" -> "المهنة والتخصص *"
                    "JOB_SEEKER" -> "المجال المطلوب *"
                    "STORE" -> "نوع النشاط *"
                    "RESTAURANT" -> "نوع المأكولات *"
                    "MEDICAL" -> "التخصصات الطبيّة *"
                    "PROPERTY" -> "أنواع العقارات *"
                    "JOB", "JOB_POSTER" -> "مجال الشركة *"
                    else -> "التخصص والنشاط *"
                }
                val specPlaceholder = when (normalizedRole) {
                    "PROVIDER", "TECHNICIAN" -> "مثال: كهربائي منازل، سباك"
                    "JOB_SEEKER" -> "مثال: محاسبة، تسويق، إدارة"
                    "STORE" -> "مثال: إلكترونيات، مواد غذائية"
                    "RESTAURANT" -> "مثال: مأكولات شعبية، وجبات سريعة"
                    "MEDICAL" -> "مثال: باطنية، أسنان، صيدلية"
                    "PROPERTY" -> "مثال: شقق تمليك، أراضي، إيجارات"
                    "JOB", "JOB_POSTER" -> "مثال: تقنية معلومات، مقاولات"
                    else -> "أدخل التخصص أو النشاط"
                }
                OutlinedTextField(
                    value = specialization,
                    onValueChange = { specialization = it },
                    label = { Text(specLabel, fontSize = 12.sp) },
                    placeholder = { Text(specPlaceholder, fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 7️⃣ حقل سنوات الخبرة
            if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "JOB_SEEKER")) {
                OutlinedTextField(
                    value = experienceYears,
                    onValueChange = { experienceYears = it },
                    label = { Text("سنوات الخبرة *", fontSize = 12.sp) },
                    placeholder = { Text("مثال: 3 سنوات", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 8️⃣ حقل ساعات العمل
            if (normalizedRole in listOf("RESTAURANT", "STORE")) {
                val hoursLabel = if (normalizedRole == "RESTAURANT") "ساعات العمل *" else "ساعات العمل (اختياري)"
                OutlinedTextField(
                    value = workingHours,
                    onValueChange = { workingHours = it },
                    label = { Text(hoursLabel, fontSize = 12.sp) },
                    placeholder = { Text("مثال: 8:00 ص - 12:00 م", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 9️⃣ المدينة (Dropdown)
            ExposedDropdownMenuBox(
                expanded = expandedCity,
                onExpandedChange = { expandedCity = !expandedCity },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = city,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("المدينة / المحافظة *", fontSize = 12.sp) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCity) },
                    singleLine = true,
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = expandedCity,
                    onDismissRequest = { expandedCity = false }
                ) {
                    cities.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c) },
                            onClick = {
                                city = c
                                expandedCity = false
                            }
                        )
                    }
                }
            }

            // 🔟 الحي / العنوان
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("الحي والعنوان *", fontSize = 12.sp) },
                placeholder = { Text("مثال: شارع الستين - بجوار جولة عصر", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // 📍 منتقي وتحديد الموقع الجغرافي التفاعلي (GPS Picker)
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = themeColors.background),
                border = BorderStroke(1.dp, if (locationDetected) Color(0xFF10B981) else themeColors.accent.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = if (locationDetected) Color(0xFF10B981) else themeColors.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    "تحديد الموقع الجغرافي (GPS) *",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    if (locationDetected) "تم تثبيت الإحداثيات بنجاح ✅" else "انقر لتحديد موقعك بدقة على الخريطة",
                                    fontSize = 10.sp,
                                    color = if (locationDetected) Color(0xFF10B981) else Color.LightGray
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val hasFine = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    android.Manifest.permission.ACCESS_FINE_LOCATION
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                val hasCoarse = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                if (hasFine || hasCoarse) {
                                    fetchDeviceLocation()
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (locationDetected) Color(0xFF10B981) else themeColors.accent,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            enabled = !isLocating
                        ) {
                            if (isLocating) {
                                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            } else {
                                Text(
                                    if (locationDetected) "تحديث الموقع 🔄" else "تحديد موقعي الآن 📍",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showMapPicker = true },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, themeColors.accent.copy(alpha = 0.55f)),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text("🗺️ اختيار من الخريطة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = themeColors.accent)
                        }
                        OutlinedButton(
                            onClick = { showManualCoords = true },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Text("🔢 إحداثيات يدوياً", fontSize = 11.sp, color = Color.White)
                        }
                    }

                    if (locationDetected && gpsCoords.isNotBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("📍 الإحداثيات:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                            Text(gpsCoords, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium)
                        }
                    }

                    if (locationErrorText != null) {
                        Text("⚠️ $locationErrorText", fontSize = 10.5.sp, color = Color(0xFFFBBF24))
                    }
                }
            }

            // 1️⃣1️⃣ خيارات إضافية خاصة (توصيل / طوارئ)
            if (normalizedRole == "RESTAURANT") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("خدمة التوصيل للمنازل (اختياري)", fontSize = 12.sp, color = Color.White)
                    Switch(
                        checked = extraOption1,
                        onCheckedChange = { extraOption1 = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = themeColors.accent)
                    )
                }
            }

            if (normalizedRole == "MEDICAL") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("خدمة الطوارئ 24 ساعة (اختياري)", fontSize = 12.sp, color = Color.White)
                    Switch(
                        checked = extraOption1,
                        onCheckedChange = { extraOption1 = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = themeColors.accent)
                    )
                }
            }

            // 1️⃣2️⃣ حقل المؤهل العلمي والسيرة الذاتية للباحث عن عمل + حقل الوصف الإضافي
            if (normalizedRole == "JOB_SEEKER") {
                OutlinedTextField(
                    value = cvUrlOrQualification,
                    onValueChange = { cvUrlOrQualification = it },
                    label = { Text("المؤهل العلمي / التخصص الأكاديمي *", fontSize = 12.sp) },
                    placeholder = { Text("مثال: بكالوريوس هندسة كهربائية أو دبلوم صيانة", fontSize = 11.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (normalizedRole in listOf("JOB_SEEKER", "PROVIDER", "TECHNICIAN", "STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER")) {
                val notesLabel = when (normalizedRole) {
                    "PROVIDER", "TECHNICIAN" -> "نبذة عن الخدمات (اختياري)"
                    "JOB_SEEKER" -> "رابط السيرة الذاتية أو نبذة عن مهاراتك (اختياري)"
                    "STORE" -> "وصف مختصر للمتجر (اختياري)"
                    "RESTAURANT" -> "وصف مختصر للمطعم (اختياري)"
                    "MEDICAL" -> "وصف المركز الطبي والتجهيزات (اختياري)"
                    "PROPERTY" -> "نبذة عن المكتب العقاري (اختياري)"
                    "JOB", "JOB_POSTER" -> "نبذة عن الشركة ومزايا العمل (اختياري)"
                    else -> "ملاحظات إضافية (اختياري)"
                }
                OutlinedTextField(
                    value = notesOrDescription,
                    onValueChange = { notesOrDescription = it },
                    label = { Text(notesLabel, fontSize = 12.sp) },
                    placeholder = { Text("أدخل تفاصيل إضافية هنا...", fontSize = 11.sp) },
                    singleLine = false,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // 1️⃣3️⃣ بطاقة الهوية أو السجل التجاري / الترخيص لجميع الفئات التجارية والمهنية
            if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER")) {
                val docTitle = when (normalizedRole) {
                    "PROVIDER", "TECHNICIAN" -> "صورة البطاقة الشخصية / رخصة المهنة (اختياري)"
                    "MEDICAL" -> "ترخيص المزاولة / السجل التجاري (اختياري)"
                    else -> "السجل التجاري / البطاقة الشخصية للمالك (اختياري)"
                }
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = themeColors.background),
                    border = BorderStroke(1.dp, themeColors.accent.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(docTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(if (idCardUri.isNotBlank()) "تم إرفاق المستند بنجاح ✅" else "لزيادة موثوقية حسابك وتسريع الاعتماد", fontSize = 10.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = { idCardPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = themeColors.accent, contentColor = Color.Black),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(if (idCardUri.isNotBlank()) "تغيير 🔄" else "إرفاق 📄", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 1️⃣4️⃣ الموافقة على الشروط (مع الإصدار والنص التفصيلي)
            com.example.ui.screens.register.components.RegistrationTermsCheckbox(
                checked = agreedToTerms,
                onCheckedChange = { agreedToTerms = it },
                themeColors = themeColors
            )

            // 🚀 زر الإرسال
            Button(
                onClick = {
                    val cleanPhone = com.example.ui.helpers.AppPreferenceHelper.normalizePhoneNumber(phone)
                    val yemenPhoneRegex = Regex("^(77|73|71|70|78)\\d{7}$")
                    val cleanPass = password.trim()
                    
                    if (fullName.trim().isBlank()) {
                        errorMessage = "يرجى تعبئة الاسم الثلاثي كاملاً"
                        return@Button
                    }
                    if (normalizedRole in listOf("STORE", "RESTAURANT", "MEDICAL", "PROPERTY", "JOB", "JOB_POSTER") && entityName.trim().isBlank()) {
                        errorMessage = "يرجى إدخال اسم المنشأة أو المحل"
                        return@Button
                    }
                    if (cleanPhone.length != 9 || !yemenPhoneRegex.matches(cleanPhone)) {
                        errorMessage = "رقم الهاتف غير صحيح. يجب أن يتكون من 9 أرقام ويبدأ بـ (77, 78, 73, 71, 70)"
                        return@Button
                    }
                    if (cleanPass.length < 7 || !cleanPass.any { it.isLetter() } || !cleanPass.any { it.isDigit() }) {
                        errorMessage = "يجب أن تتكون كلمة المرور من 7 خانات على الأقل وتحتوي حروفاً وأرقاماً"
                        return@Button
                    }
                    if (cleanPass != confirmPassword.trim()) {
                        errorMessage = "كلمتا المرور غير متطابقتين"
                        return@Button
                    }
                    if (city.isBlank()) {
                        errorMessage = "يرجى تحديد المدينة أو المحافظة"
                        return@Button
                    }
                    if (address.trim().isBlank()) {
                        errorMessage = "يرجى إدخال الحي والعنوان التفصيلي"
                        return@Button
                    }
                    if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "JOB_SEEKER") && specialization.trim().isBlank()) {
                        errorMessage = "يرجى إدخال المهنة أو التخصص المطلوب"
                        return@Button
                    }
                    if (normalizedRole in listOf("PROVIDER", "TECHNICIAN", "STORE", "RESTAURANT", "MEDICAL", "PROPERTY") && (!locationDetected || gpsCoords.isBlank())) {
                        errorMessage = "يرجى تحديد الموقع الجغرافي (GPS) أو اختياره من الخريطة لضمان ظهورك للعملاء القريبين"
                        return@Button
                    }
                    if (!agreedToTerms) {
                        errorMessage = "يرجى قراءة الشروط والأحكام والموافقة عليها للمتابعة"
                        return@Button
                    }

                    val resolvedGps = if (gpsCoords.isNotBlank()) gpsCoords else if (locationDetected) "$latitude,$longitude" else ""
                    val metadataJson = org.json.JSONObject().apply {
                        put("description", notesOrDescription.trim())
                        put("qualification", cvUrlOrQualification.trim())
                        put("experienceYears", experienceYears.trim())
                        put("workingHours", workingHours.trim())
                        put("hasDelivery", extraOption1 && normalizedRole == "RESTAURANT")
                        put("hasEmergency", extraOption1 && normalizedRole == "MEDICAL")
                    }.toString()

                    isSubmitting = true
                    errorMessage = null

                    val resultData: Map<String, String> = mapOf(
                        "role" to normalizedRole,
                        "fullName" to fullName.trim(),
                        "entityName" to entityName.ifBlank { fullName }.trim(),
                        "phone" to cleanPhone,
                        "password" to cleanPass,
                        "city" to city.trim(),
                        "address" to address.trim(),
                        "gpsCoords" to resolvedGps,
                        "latitude" to latitude.toString(),
                        "longitude" to longitude.toString(),
                        "craftType" to specialization.trim(),
                        "specialization" to specialization.trim(),
                        "experienceYears" to experienceYears.trim(),
                        "workingHours" to workingHours.trim(),
                        "description" to notesOrDescription.trim(),
                        "cvUrlOrQualification" to cvUrlOrQualification.trim(),
                        "hasDelivery" to extraOption1.toString(),
                        "hasEmergency" to extraOption1.toString(),
                        "productAttachmentsJson" to metadataJson,
                        "imageUri" to imageUri,
                        "idCardUri" to idCardUri
                    )

                    onRegistrationSuccess(resultData)
                },
                enabled = !isSubmitting,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = themeColors.accent, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                } else {
                    Text("إرسال طلب التسجيل للأدمن 🚀", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showMapPicker) {
        com.example.ui.components.InteractiveMapLocationPickerDialog(
            initialLat = latitude,
            initialLng = longitude,
            hasGps = locationDetected,
            gpsLat = latitude,
            gpsLng = longitude,
            title = "📍 حدد موقع النشاط / السكن على الخريطة",
            onDismiss = { showMapPicker = false },
            onLocationPicked = { picked ->
                applyPickedCoordinates(picked.latitude, picked.longitude, picked.landmarkName.ifBlank { picked.label })
                showMapPicker = false
            }
        )
    }

    if (showManualCoords) {
        com.example.ui.components.ManualCoordinateDialog(
            initialLat = if (locationDetected) latitude else 0.0,
            initialLng = if (locationDetected) longitude else 0.0,
            gpsLat = latitude,
            gpsLng = longitude,
            hasGps = locationDetected,
            onDismiss = { showManualCoords = false },
            onConfirm = { lat, lng, summary ->
                applyPickedCoordinates(lat, lng, summary)
                showManualCoords = false
            }
        )
    }
}
