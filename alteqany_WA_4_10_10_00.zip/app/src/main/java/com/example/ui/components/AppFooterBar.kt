package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import com.example.ui.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.utils.VisualThemePalette

@Composable
fun AppFooterBar(viewModel: MainViewModel, themeColors: VisualThemePalette, onInfoClick: () -> Unit) {
    val settingsState by viewModel.settings.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isEn = currentLang == "en"

    val footerBg = remember(settingsState.footerBgColorHex, themeColors.secondary) {
        try {
            Color(android.graphics.Color.parseColor(settingsState.footerBgColorHex))
        } catch (e: Exception) {
            Color(0xFF0D332D) // Dark teal metallic container like image 2
        }
    }

    Surface(
        color = footerBg,
        shadowElevation = 6.dp,
        border = BorderStroke(0.8.dp, Brush.horizontalGradient(listOf(Color(0xFF0F5243), Color(0xFF1B8A72), Color(0xFF0F5243)))),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .testTag("app_footer_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 1.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            val bookings by viewModel.bookings.collectAsState()
            val currentUserPhone by viewModel.currentUserPhone.collectAsState()
            val providers by viewModel.providers.collectAsState()

            val activeStatuses = remember { setOf("PENDING", "ACCEPTED", "APPROVED", "IN_PROGRESS", "STARTED") }
            val cleanUserPhone = remember(currentUserPhone) { com.example.ui.helpers.AppPreferenceHelper.normalizePhoneNumber(currentUserPhone) }

            val matchingProvider = remember(providers, cleanUserPhone) {
                providers.find { com.example.ui.helpers.AppPreferenceHelper.normalizePhoneNumber(it.phone) == cleanUserPhone && cleanUserPhone.isNotEmpty() }
            }

            val unreadCount = remember(bookings, cleanUserPhone, matchingProvider) {
                val custCount = bookings.count { b ->
                    com.example.ui.helpers.AppPreferenceHelper.normalizePhoneNumber(b.customerPhone) == cleanUserPhone && cleanUserPhone.isNotEmpty() && b.status.uppercase() in activeStatuses
                }
                val provCount = if (matchingProvider != null) {
                    bookings.count { b ->
                        b.providerId == matchingProvider.id && b.status.uppercase() in activeStatuses
                    }
                } else 0
                custCount + provCount
            }

            // 1. Info Icon ("عن التطبيق")
            if (settingsState.showInfoIcon) {
                val isAbout = currentScreen == AppScreens.ABOUT_APP
                Luxury3DNavIcon(
                    emojiIcon = settingsState.bottomInfoIcon.ifEmpty { "ℹ️" },
                    vectorIcon = Icons.Default.Info,
                    label = if (isEn) "About" else "عن التطبيق",
                    isSelected = isAbout,
                    iconSizeDp = settingsState.navIconSizeDp,
                    iconStyle = settingsState.topNavIconStyle,
                    onClick = { onInfoClick() }
                )
            }

            // 2. Bookings Icon ("الحجوزات")
            if (settingsState.showBookingsIcon) {
                val isBookings = currentScreen == AppScreens.BOOKINGS_VIEW
                Luxury3DNavIcon(
                    emojiIcon = settingsState.bottomBookingsIcon.ifEmpty { "📅" },
                    vectorIcon = Icons.Default.DateRange,
                    label = if (isEn) "Bookings" else "الحجوزات",
                    isSelected = isBookings,
                    badgeCount = unreadCount,
                    iconSizeDp = settingsState.navIconSizeDp,
                    iconStyle = settingsState.topNavIconStyle,
                    onClick = { viewModel.navigateTo("BOOKINGS_VIEW") }
                )
            }

            // 3. Center Brand Text ("WAM2026")
            if (settingsState.showFooterText) {
                Box(
                    modifier = Modifier.padding(horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (settingsState.footerMessage.startsWith("card_custom_")) "WAM2026" else settingsState.footerMessage.ifBlank { "WAM2026" },
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFE2E8F0),
                        letterSpacing = 0.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 4. Single Clean Language Switcher Icon ("EN" / "🌐")
            if (settingsState.showLangIcon) {
                Luxury3DNavIcon(
                    emojiIcon = settingsState.bottomLangIcon.ifEmpty { if (isEn) "🌐" else "EN" },
                    vectorIcon = null,
                    label = if (isEn) "العربية" else "English",
                    isSelected = false,
                    iconSizeDp = settingsState.navIconSizeDp,
                    iconStyle = settingsState.topNavIconStyle,
                    onClick = {
                        viewModel.switchLanguage()
                        viewModel.triggerNotification(
                            if (isEn) "تم التحويل إلى اللغة العربية 🇾🇪" else "Language switched to English 🌐"
                        )
                    }
                )
            }

            // 5. Admin Lock Icon ("الإدارة")
            if (settingsState.showAdminIcon) {
                val isAdmin = currentScreen == AppScreens.ADMIN_PANEL
                Luxury3DNavIcon(
                    emojiIcon = settingsState.bottomAdminIcon.ifEmpty { "🔒" },
                    vectorIcon = Icons.Default.Lock,
                    label = if (isEn) "Admin" else "الإدارة",
                    isSelected = isAdmin,
                    iconSizeDp = settingsState.navIconSizeDp,
                    iconStyle = settingsState.topNavIconStyle,
                    onClick = { viewModel.navigateTo("ADMIN_PANEL") }
                )
            }
        }
    }
}
