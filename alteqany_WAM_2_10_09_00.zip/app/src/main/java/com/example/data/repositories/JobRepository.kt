package com.example.data.repositories

import com.example.data.LocalAppCacheManager
import com.example.domain.entities.JobPostItem
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class JobRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    cacheManager: LocalAppCacheManager
) {
    fun getJobs(ownerId: String): Flow<List<JobPostItem>> = callbackFlow {
        val listener = firestore.collection(com.example.utils.AppConstants.COL_JOBS)
            .whereEqualTo("ownerId", ownerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot.documents.mapNotNull { doc ->
                    JobPostItem(
                        id = doc.id,
                        title = doc.getString("title") ?: doc.getString("jobTitle") ?: "",
                        companyName = doc.getString("companyName") ?: "",
                        salary = doc.getString("salary") ?: doc.getString("salaryRange") ?: "",
                        requirements = doc.getString("requirements") ?: doc.getString("jobRequirements") ?: "",
                        applicantsCount = doc.getLong("applicantsCount")?.toInt() ?: 0
                    )
                }
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun postJob(ownerId: String, job: JobPostItem): Result<String> {
        return try {
            val docId = job.id.ifBlank { java.util.UUID.randomUUID().toString() }
            val data = mapOf(
                "id" to docId,
                "ownerId" to ownerId,
                "title" to job.title,
                "jobTitle" to job.title,
                "companyName" to job.companyName,
                "salary" to job.salary,
                "salaryRange" to job.salary,
                "requirements" to job.requirements,
                "applicantsCount" to job.applicantsCount,
                "createdAt" to System.currentTimeMillis()
            )
            firestore.collection(com.example.utils.AppConstants.COL_JOBS).document(docId).set(data).await()
            Result.success(docId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteJob(id: String): Result<Unit> {
        if (id.isBlank()) return Result.failure(IllegalArgumentException("Job ID is blank"))
        return try {
            firestore.collection(com.example.utils.AppConstants.COL_JOBS).document(id).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
