package com.example.data.repositories

import android.content.Context
import android.util.Log
import com.example.data.models.InstantRequestEntity
import com.example.data.models.RequestOfferEntity
import com.example.security.BookingSecurityHelper
import com.example.utils.AnalyticsEventsHelper
import com.example.utils.AppConstants
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

/**
 * ⚡ InstantRequestRepository
 * مستودع إدارة الطلبات الفورية والعاجلة مع دعم التدفق الحي (Flow)،
 * المؤقت التنازلي للطلب (30 دقيقة)، تقديم العروض، والمصادقة الأمنية.
 */
class InstantRequestRepository(private val context: Context? = null) {

    private val repositoryScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)

    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val _requests = MutableStateFlow<List<InstantRequestEntity>>(emptyList())
    val requests: StateFlow<List<InstantRequestEntity>> = _requests.asStateFlow()

    /**
     * 1. إنشاء طلب فوري جديد مع مؤقت زمني مدته 30 دقيقة
     */
    fun createInstantRequest(
        request: InstantRequestEntity,
        onSuccess: (InstantRequestEntity) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        try {
            val docId = if (request.id.isNotBlank()) request.id else firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document().id
            val requestCode = if (request.requestCode.isNotBlank()) request.requestCode else "URG-${Random.nextInt(100000, 999999)}"
            val inputRawPin = request.rawPin
            val rawPin = if (inputRawPin.isNotBlank()) inputRawPin else "${Random.nextInt(1000, 9999)}"
            val pin = if (rawPin.startsWith("$2a$") || rawPin.startsWith("$2b$") || rawPin.contains(":")) {
                rawPin
            } else {
                com.example.utils.SecureHasher.hashPin(rawPin)
            }
            val rawCancelPass = if (request.cancellationPassword.isNotBlank()) request.cancellationPassword else rawPin
            val cancelPass = if (rawCancelPass.startsWith("$2a$") || rawCancelPass.startsWith("$2b$") || rawCancelPass.contains(":")) {
                rawCancelPass
            } else {
                com.example.utils.SecureHasher.hashPin(rawCancelPass)
            }
            val now = System.currentTimeMillis()
            val expiresAt = if (request.expiresAt > now) request.expiresAt else now + (30 * 60 * 1000L) // 30 mins

            val newEntity = request.copy(
                id = docId,
                requestCode = requestCode,
                pinHash = pin,
                rawPin = rawPin,
                cancellationPassword = cancelPass,
                status = if (request.status.isBlank()) "WAITING_FOR_OFFERS" else request.status,
                createdAt = if (request.createdAt > 0) request.createdAt else now,
                expiresAt = expiresAt
            )
            val entityForFirestore = newEntity.copy(rawPin = "")

            firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(docId).set(entityForFirestore)
                .addOnSuccessListener {
                    val current = _requests.value.toMutableList()
                    current.removeAll { it.id == docId }
                    current.add(0, newEntity)
                    _requests.value = current
                    AnalyticsEventsHelper.logUrgentRequestCreated(context, docId, newEntity.categoryName.ifBlank { newEntity.serviceTitle })
                    onSuccess(newEntity)
                }
                .addOnFailureListener {
                    onError(it.localizedMessage ?: "فشل إنشاء الطلب الفوري")
                }
        } catch (e: Exception) {
            Log.e("InstantRequestRepo", "Error creating instant request", e)
            onError(e.localizedMessage ?: "خطأ غير متوقع أثناء معالجة الطلب")
        }
    }

    /**
     * 2. تدفق حي لطلبات مستخدم معين (العميل)
     */
    fun getUserInstantRequests(userId: String): Flow<List<InstantRequestEntity>> = callbackFlow {
        val listener: ListenerRegistration = firestore.collection(AppConstants.COL_INSTANT_REQUESTS)
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    trySend(_requests.value.filter { it.userId == userId })
                    return@addSnapshotListener
                }

                val list = snapshot.documents.mapNotNull { doc ->
                    try {
                        doc.toObject(InstantRequestEntity::class.java)?.copy(id = doc.id)
                    } catch (e: Exception) {
                        null
                    }
                }
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    /**
     * 3. تدفق حي للطلبات المتاحة للفنيين في مدينة/تصنيف معين (فلترة على السيرفر)
     */
    fun getAvailableInstantRequests(category: String = "", city: String = ""): Flow<List<InstantRequestEntity>> = callbackFlow {
        val now = System.currentTimeMillis()
        var query: Query = firestore.collection(AppConstants.COL_INSTANT_REQUESTS)
            .whereEqualTo("status", "WAITING_FOR_OFFERS")
            .whereGreaterThan("expiresAt", now)

        if (city.isNotBlank()) {
            query = query.whereEqualTo("userCity", city.trim())
        }
        if (category.isNotBlank()) {
            query = query.whereEqualTo("categoryName", category.trim())
        }

        query = query.orderBy("expiresAt", Query.Direction.DESCENDING).limit(50)

        var fallbackRegistration: ListenerRegistration? = null
        val listener: ListenerRegistration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                // Fallback query if composite index is still building in Firestore
                if (fallbackRegistration == null) {
                    fallbackRegistration = firestore.collection(AppConstants.COL_INSTANT_REQUESTS)
                        .whereEqualTo("status", "WAITING_FOR_OFFERS")
                        .whereGreaterThan("expiresAt", System.currentTimeMillis())
                        .limit(50)
                        .addSnapshotListener { fbSnap, fbErr ->
                            if (fbErr != null || fbSnap == null) {
                                trySend(emptyList())
                                return@addSnapshotListener
                            }
                            val currentMillis = System.currentTimeMillis()
                            val fbList = fbSnap.documents.mapNotNull { doc ->
                                runCatching { doc.toObject(InstantRequestEntity::class.java)?.copy(id = doc.id) }.getOrNull()
                            }.filter { item ->
                                (category.isBlank() || item.categoryName.contains(category, ignoreCase = true) || item.serviceTitle.contains(category, ignoreCase = true)) &&
                                    (city.isBlank() || item.userCity.contains(city, ignoreCase = true)) &&
                                    (item.expiresAt > currentMillis)
                            }
                            trySend(fbList)
                        }
                }
                return@addSnapshotListener
            }

            if (snapshot == null) {
                trySend(emptyList())
                return@addSnapshotListener
            }

            val currentMillis = System.currentTimeMillis()
            val list = snapshot.documents.mapNotNull { doc ->
                try {
                    doc.toObject(InstantRequestEntity::class.java)?.copy(id = doc.id)
                } catch (e: Exception) {
                    null
                }
            }.filter { item ->
                item.expiresAt > currentMillis
            }

            trySend(list)
        }

        awaitClose {
            listener.remove()
            fallbackRegistration?.remove()
        }
    }

    /**
     * 4. تقديم عرض سعر من مزود خدمة على طلب فوري
     */
    fun submitOffer(
        offer: RequestOfferEntity,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val offerId = if (offer.id.isNotBlank()) offer.id else com.example.utils.EntityIdGenerator.generateOfferId()
        val finalOffer = offer.copy(id = offerId, createdAt = System.currentTimeMillis())

        val offerRef = firestore.collection(AppConstants.COL_INSTANT_REQUESTS)
            .document(offer.requestId)
            .collection("offers")
            .document(offerId)

        val topLevelOfferRef = firestore.collection("request_offers").document(offerId)
        val requestRef = firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(offer.requestId)

        firestore.runTransaction { transaction ->
            val snapshot = transaction.get(requestRef)
            val currentOffers = snapshot.getLong("offersCount") ?: 0L
            transaction.set(offerRef, finalOffer)
            transaction.set(topLevelOfferRef, finalOffer)
            transaction.update(requestRef, "offersCount", currentOffers + 1)
        }.addOnSuccessListener {
            AnalyticsEventsHelper.logOfferSubmitted(context, offer.requestId, offer.technicianId, offer.price)
            onSuccess()
        }.addOnFailureListener {
            onError(it.localizedMessage ?: "فشل تقديم العرض")
        }
    }

    /**
     * 5. قبول عرض السعر وبدء الخدمة
     */
    fun acceptOffer(
        requestId: String,
        offerId: String,
        providerId: String,
        providerName: String,
        providerPhone: String,
        acceptedPrice: Double,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val now = System.currentTimeMillis()
        val updates = mapOf(
            "status" to "ACCEPTED",
            "acceptedOfferId" to offerId,
            "acceptedTechnicianId" to providerId,
            "acceptedTechnicianName" to providerName,
            "acceptedTechnicianPhone" to providerPhone,
            "acceptedPrice" to acceptedPrice,
            "acceptedAt" to now,
            "updatedAt" to now
        )

        val requestRef = firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(requestId)
        val offerRef = requestRef.collection("offers").document(offerId)
        val topLevelOfferRef = firestore.collection("request_offers").document(offerId)

        val onOfferAcceptedSuccess = {
            offerRef.update("status", "ACCEPTED")
            topLevelOfferRef.update("status", "ACCEPTED")

            // Mark other competing offers for the same request as REJECTED
            requestRef.collection("offers")
                .get()
                .addOnSuccessListener { snap ->
                    snap.documents.forEach { doc ->
                        if (doc.id != offerId && doc.getString("status") == "PENDING") {
                            doc.reference.update("status", "REJECTED")
                            firestore.collection("request_offers").document(doc.id).update("status", "REJECTED")
                        }
                    }
                }

            _requests.value = _requests.value.map {
                if (it.id == requestId) it.copy(
                    status = "ACCEPTED",
                    acceptedOfferId = offerId,
                    acceptedTechnicianId = providerId,
                    acceptedTechnicianName = providerName,
                    acceptedTechnicianPhone = providerPhone,
                    acceptedPrice = acceptedPrice
                ) else it
            }
            context?.let { ctx ->
                repositoryScope.launch {
                    try {
                        com.example.data.local.AppDatabase.getInstance(ctx).requestDao()
                            .updateRequestStatus(requestId, "ACCEPTED")
                    } catch (_: Exception) {}
                }
            }
            AnalyticsEventsHelper.logOfferAccepted(context, requestId, providerId)
            onSuccess()
        }

        requestRef.get()
            .addOnSuccessListener { snapshot ->
                if (snapshot != null && snapshot.exists()) {
                    val currentStatus = snapshot.getString("status")?.uppercase() ?: "WAITING_FOR_OFFERS"
                    val currentAcceptedOffer = snapshot.getString("acceptedOfferId") ?: ""
                    if (currentStatus in setOf("CANCELLED", "COMPLETED", "EXPIRED") ||
                        (currentStatus == "ACCEPTED" && currentAcceptedOffer.isNotBlank() && currentAcceptedOffer != offerId)
                    ) {
                        onError("لا يمكن قبول العرض لأن حالة الطلب الحالية هي: $currentStatus")
                        return@addOnSuccessListener
                    }
                }
                requestRef.update(updates)
                    .addOnSuccessListener { onOfferAcceptedSuccess() }
                    .addOnFailureListener { onError(it.localizedMessage ?: "فشل قبول العرض") }
            }
            .addOnFailureListener {
                // في حال تعذر القراءة المسبقة (أوفلاين) نحاول التحديث المباشر
                requestRef.update(updates)
                    .addOnSuccessListener { onOfferAcceptedSuccess() }
                    .addOnFailureListener { err -> onError(err.localizedMessage ?: "فشل قبول العرض") }
            }
    }

    /**
     * 6. إلغاء الطلب الفوري مع التحقق الأمني
     */
    fun cancelInstantRequest(
        requestId: String,
        userPin: String = "",
        cancelReason: String = "",
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(requestId).get()
            .addOnSuccessListener { doc ->
                val request = doc.toObject(InstantRequestEntity::class.java)
                if (request == null) {
                    onError("الطلب غير موجود")
                    return@addOnSuccessListener
                }

                if (userPin.isNotBlank()) {
                    val expectedPass = request.effectivePinHash
                    val isValid = com.example.utils.SecureHasher.verifyPin(userPin, expectedPass) ||
                            BookingSecurityHelper.verifyPassword(userPin, expectedPass)
                    if (expectedPass.isNotBlank() && !isValid) {
                        onError("رمز PIN للإلغاء غير صحيح")
                        return@addOnSuccessListener
                    }
                }

                val updates = mutableMapOf<String, Any>(
                    "status" to "CANCELLED",
                    "cancelledAt" to System.currentTimeMillis(),
                    "updatedAt" to System.currentTimeMillis()
                )
                if (cancelReason.isNotBlank()) {
                    updates["cancelReason"] = cancelReason
                }

                firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(requestId).update(updates)
                    .addOnSuccessListener {
                        _requests.value = _requests.value.map {
                            if (it.id == requestId) it.copy(status = "CANCELLED", cancelReason = cancelReason) else it
                        }
                        onSuccess()
                    }
                    .addOnFailureListener { onError(it.localizedMessage ?: "فشل إلغاء الطلب") }
            }
            .addOnFailureListener { onError(it.localizedMessage ?: "فشل الوصول لبيانات الطلب") }
    }

    /**
     * 7. إكمال الطلب الفوري بنجاح
     */
    fun completeInstantRequest(
        requestId: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val updates = mapOf(
            "status" to "COMPLETED",
            "completedAt" to System.currentTimeMillis(),
            "updatedAt" to System.currentTimeMillis()
        )

        firestore.collection(AppConstants.COL_INSTANT_REQUESTS).document(requestId).update(updates)
            .addOnSuccessListener {
                _requests.value = _requests.value.map {
                    if (it.id == requestId) it.copy(status = "COMPLETED") else it
                }
                onSuccess()
            }
            .addOnFailureListener { onError(it.localizedMessage ?: "فشل إكمال الطلب") }
    }
}
