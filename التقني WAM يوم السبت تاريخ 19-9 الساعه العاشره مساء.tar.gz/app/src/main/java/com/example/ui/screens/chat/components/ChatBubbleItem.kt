package com.example.ui.screens.chat.components

import android.content.Intent
import com.example.ui.*
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.models.ChatMessage
import com.example.data.models.MediaType
import com.example.data.models.MessageStatus
import com.example.utils.AudioPlayerManager
import com.example.utils.ChatIcons
import com.example.utils.DateFormatter
import java.util.*

import com.example.utils.VisualThemePalette

@Composable
fun ChatBubbleItem(
    message: ChatMessage,
    isMe: Boolean,
    onReplyClick: () -> Unit,
    onLongClick: () -> Unit,
    onRetryClick: ((String) -> Unit)? = null,
    themeColors: VisualThemePalette? = null
) {
    val isSupport = !isMe && (
        message.senderId.contains("admin", ignoreCase = true) ||
        message.senderId.contains("support", ignoreCase = true) ||
        message.senderName.contains("الدعم", ignoreCase = true) ||
        message.senderName.contains("إدارة", ignoreCase = true) ||
        message.senderName.contains("الادارة", ignoreCase = true)
    )

    val primaryColor = themeColors?.primary ?: Color(0xFF1E88E5)
    val surfaceColor = themeColors?.surface ?: Color(0xFF1E293B)
    val accentColor = themeColors?.accent ?: Color(0xFF00E5FF)
    val textPrimaryColor = themeColors?.textPrimary ?: Color.White
    val textSecondaryColor = themeColors?.textSecondary ?: Color.LightGray

    val bubbleColor = when {
        isMe -> primaryColor
        isSupport -> Color(0xFF112618)
        else -> surfaceColor
    }

    val textColor = textPrimaryColor
    // ✨ م2-ج3: استخدام DateFormatter
    val formattedTime = DateFormatter.formatTime(message.timestamp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isMe) 16.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 16.dp
                    )
                )
                .then(
                    if (isSupport) {
                        Modifier.border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFFFFD700), Color(0xFF10B981))
                            ),
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = 4.dp,
                                bottomEnd = 16.dp
                            )
                        )
                    } else Modifier
                )
                .background(bubbleColor)
                .clickable { onLongClick() }
                .padding(10.dp)
        ) {
            // Support badge
            if (isSupport) {
                Text(
                    text = "🛠️ الدعم الفني والإدارة",
                    fontSize = 10.sp,
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            // Replying quote preview
            if (!message.replyToText.isNullOrBlank()) {
                Surface(
                    color = Color.Black.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(28.dp)
                                .background(Color(0xFF64B5F6), RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = message.replyToText,
                            fontSize = 11.sp,
                            color = Color.LightGray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Media attachment
            when (message.mediaType) {
                MediaType.IMAGE -> {
                    if (message.mediaUrl.isNotBlank()) {
                        AsyncImage(
                            model = message.mediaUrl,
                            contentDescription = "صورة مرفقة",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
                MediaType.AUDIO -> {
                    val context = LocalContext.current
                    val currentPlayingId by AudioPlayerManager.currentPlayingId.collectAsState()
                    val isAudioPlaying by AudioPlayerManager.isPlaying.collectAsState()
                    val liveProgress by AudioPlayerManager.playbackProgress.collectAsState()
                    val isThisAudioActive = currentPlayingId == message.id && isAudioPlaying

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (isThisAudioActive) {
                                    AudioPlayerManager.pause()
                                } else if (currentPlayingId == message.id) {
                                    AudioPlayerManager.resume()
                                } else {
                                    val source = message.mediaUrl.ifBlank { message.attachment?.url.orEmpty() }
                                    AudioPlayerManager.play(message.id, source, context)
                                }
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .background(if (isThisAudioActive) Color(0xFF10B981) else Color.White.copy(alpha = 0.18f), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isThisAudioActive) ChatIcons.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isThisAudioActive) "إيقاف مؤقت" else "تشغيل التسجيل",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = message.message.ifBlank { "تسجيل صوتي 🎤" },
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { if (currentPlayingId == message.id) liveProgress else 0f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = if (isThisAudioActive) Color(0xFF10B981) else Color(0xFF64FFDA),
                                trackColor = Color.White.copy(alpha = 0.2f),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }
                MediaType.LOCATION -> {
                    val context = LocalContext.current
                    Surface(
                        color = Color.Black.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clickable {
                                try {
                                    val uri = if (message.mediaUrl.startsWith("geo:") || message.mediaUrl.startsWith("http")) {
                                        Uri.parse(message.mediaUrl)
                                    } else {
                                        Uri.parse("https://maps.google.com/?q=${message.mediaUrl}")
                                    }
                                    val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                                    mapIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    context.startActivity(mapIntent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "تعذر فتح تطبيق الخرائط", Toast.LENGTH_SHORT).show()
                                }
                            }
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0xFF1E3A8A), Color(0xFF0F172A))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "موقع جغرافي",
                                        tint = Color(0xFFEF4444),
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "موقع جغرافي مباشر 📍",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "اضغط لعرض المكان على خرائط Google",
                                        color = Color(0xFF93C5FD),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🗺️ فتح الموقع بالخريطة",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF60A5FA)
                                )
                                Text(
                                    text = "Google Maps ↗",
                                    fontSize = 10.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }
                }
                MediaType.FILE -> {
                    Text("📎 ${message.message.ifBlank { "ملف مرفق" }}", color = Color(0xFF90CAF9), fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                }
                else -> {}
            }

            // Message text
            if (message.message.isNotBlank() && message.mediaType != MediaType.FILE && message.mediaType != MediaType.LOCATION) {
                Text(
                    text = message.message,
                    color = textColor,
                    fontSize = 13.5.sp,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Time & Status Indicators
            Row(
                modifier = Modifier.align(Alignment.End),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (message.isEdited) {
                    Text(
                        text = "معدلة",
                        fontSize = 9.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        fontWeight = FontWeight.Light
                    )
                }

                Text(
                    text = formattedTime,
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )

                if (isMe) {
                    val isRead = message.status == MessageStatus.READ
                    when {
                        message.status == MessageStatus.FAILED -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable { onRetryClick?.invoke(message.id) }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "إعادة المحاولة",
                                    tint = Color(0xFFFF8A80),
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "إعادة الإرسال",
                                    fontSize = 9.sp,
                                    color = Color(0xFFFF8A80),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        message.status == MessageStatus.PENDING || message.status == MessageStatus.SENDING -> {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "قيد الإرسال",
                                tint = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        isRead -> {
                            Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "تمت القراءة",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(14.dp)
                                )
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "تمت القراءة",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        message.status == MessageStatus.DELIVERED -> {
                            Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "تم الاستلام",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(13.dp)
                                )
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "تم الاستلام",
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                        else -> {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "تم الإرسال",
                                tint = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
