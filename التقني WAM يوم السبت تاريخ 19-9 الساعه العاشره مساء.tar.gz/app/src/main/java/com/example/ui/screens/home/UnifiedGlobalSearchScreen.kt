package com.example.ui.screens.home

import androidx.compose.foundation.layout.*
import com.example.ui.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.AnalyticsEventsHelper
import com.example.utils.VisualThemePalette
import kotlinx.coroutines.delay

@Composable
fun UnifiedGlobalSearchScreen(
    themeColors: VisualThemePalette,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    val sampleResults = listOf("صيانة مكيفات (فنيون)", "مطعم الشيباني (مطاعم)", "أجهزة ذكية (متاجر)", "شقة للإيجار (عقارات)")

    LaunchedEffect(searchQuery) {
        if (searchQuery.trim().length >= 2) {
            delay(500)
            AnalyticsEventsHelper.logSearchPerformed(context, searchQuery.trim())
        }
    }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("بحث موحد في جميع الأقسام والخدمات...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            val filtered = sampleResults.filter { it.contains(searchQuery, ignoreCase = true) }
            items(filtered) { result ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = result,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(16.dp),
                        color = themeColors.primary
                    )
                }
            }
        }
    }
}
